import { INTEGRATION_URLS, SERVICE_CONFIG } from '../config/constants';

// Microsoft Teams Integration
export const openTeams = (channel?: string) => {
  const url = channel 
    ? `${INTEGRATION_URLS.teams}/${SERVICE_CONFIG.teams.workspaceId}/${channel}`
    : INTEGRATION_URLS.teams;
  window.open(url, '_blank');
};

// SharePoint Integration
export const openSharePoint = (library?: string) => {
  const url = library
    ? `${INTEGRATION_URLS.sharepoint}/sites/${SERVICE_CONFIG.sharepoint.siteId}/${library}`
    : INTEGRATION_URLS.sharepoint;
  window.open(url, '_blank');
};

// Planner Integration
export const openPlanner = (planId?: string) => {
  const url = planId
    ? `${INTEGRATION_URLS.planner}/${planId}`
    : `${INTEGRATION_URLS.planner}/${SERVICE_CONFIG.planner.planId}`;
  window.open(url, '_blank');
};

// Salesforce Integration
export const openSalesforce = (page?: 'analytics' | 'leads') => {
  const url = page === 'analytics' 
    ? INTEGRATION_URLS.salesforceAnalytics
    : page === 'leads'
    ? INTEGRATION_URLS.salesforceLeads
    : INTEGRATION_URLS.salesforce;
  window.open(url, '_blank');
};

// SAP Integration
export const openSAP = (page?: 'analytics') => {
  const url = page === 'analytics'
    ? INTEGRATION_URLS.sapAnalytics
    : INTEGRATION_URLS.sap;
  window.open(url, '_blank');
};

// Outlook Integration
export const openOutlook = (view?: 'calendar' | 'mail') => {
  const url = `${INTEGRATION_URLS.outlook}/${view || ''}`;
  window.open(url, '_blank');
};

// Power BI Integration
export const openPowerBI = (dashboard?: string) => {
  const url = dashboard
    ? `${INTEGRATION_URLS.powerbi}/dashboards/${dashboard}`
    : INTEGRATION_URLS.powerbi;
  window.open(url, '_blank');
};