import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Announcement, NotificationItem } from '../types';

interface UserPoints {
  marketing: number;
  sales: number;
  innovation: number;
  leadership: number;
}

interface User {
  id: string;
  name: string;
  role: string;
  points: UserPoints;
}

interface StoreState {
  darkMode: boolean;
  user: User;
  announcements: Announcement[];
  notifications: NotificationItem[];
  setAnnouncements: (announcements: Announcement[]) => void;
  addAnnouncement: (announcement: Announcement) => void;
  setNotifications: (notifications: NotificationItem[]) => void;
  addNotification: (notification: NotificationItem) => void;
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  removeNotification: (id: string) => void;
  toggleDarkMode: () => void;
}

export const useStore = create<StoreState>()(
  persist(
    (set) => ({
      darkMode: false,
      user: {
        id: '1',
        name: 'Peter Schuck',
        role: 'Vice President Global Sales and Marketing Woundcare',
        points: {
          marketing: 85,
          sales: 75,
          innovation: 65,
          leadership: 80
        }
      },
      announcements: [],
      notifications: [],
      setAnnouncements: (announcements) => set({ announcements }),
      addAnnouncement: (announcement) =>
        set((state) => ({
          announcements: [...state.announcements, announcement],
        })),
      setNotifications: (notifications) => set({ notifications }),
      addNotification: (notification) =>
        set((state) => ({
          notifications: [...state.notifications, notification],
        })),
      markNotificationAsRead: (id) =>
        set((state) => ({
          notifications: state.notifications.map((n) =>
            n.id === id ? { ...n, read: true } : n
          ),
        })),
      markAllNotificationsAsRead: () =>
        set((state) => ({
          notifications: state.notifications.map((n) => ({ ...n, read: true })),
        })),
      removeNotification: (id) =>
        set((state) => ({
          notifications: state.notifications.filter((n) => n.id !== id),
        })),
      toggleDarkMode: () => set((state) => ({ darkMode: !state.darkMode })),
    }),
    {
      name: 'wounderland-store',
      version: 1,
    }
  )
);