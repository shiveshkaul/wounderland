import { Client } from '@microsoft/microsoft-graph-client';
import * as microsoftTeams from '@microsoft/teams-js';

export class MicrosoftIntegration {
  private graphClient: Client;

  constructor(graphClient: Client) {
    this.graphClient = graphClient;
  }

  async initializeTeams() {
    try {
      await microsoftTeams.app.initialize();
      return true;
    } catch (error) {
      console.error('Not running in Microsoft Teams:', error);
      return false;
    }
  }

  async getSharePointDocuments(siteId: string, libraryId: string) {
    try {
      const response = await this.graphClient
        .api(`/sites/${siteId}/drives/${libraryId}/root/children`)
        .get();
      return response;
    } catch (error) {
      console.error('Error fetching SharePoint documents:', error);
      throw error;
    }
  }

  async uploadToSharePoint(siteId: string, libraryId: string, file: File) {
    try {
      const response = await this.graphClient
        .api(`/sites/${siteId}/drives/${libraryId}/root:/${file.name}:/createUploadSession`)
        .post({});
      return response;
    } catch (error) {
      console.error('Error uploading to SharePoint:', error);
      throw error;
    }
  }
}