export class SAPIntegration {
  private baseUrl: string;
  private token: string;

  constructor(baseUrl: string, token: string) {
    this.baseUrl = baseUrl;
    this.token = token;
  }

  private async fetch(endpoint: string, options: RequestInit = {}) {
    const response = await fetch(`${this.baseUrl}${endpoint}`, {
      ...options,
      headers: {
        'Authorization': `Bearer ${this.token}`,
        'Content-Type': 'application/json',
        ...options.headers
      }
    });

    if (!response.ok) {
      throw new Error(`SAP API error: ${response.statusText}`);
    }

    return response.json();
  }

  // Sales Performance Analytics
  async getSalesMetrics(startDate: string, endDate: string) {
    return this.fetch('/sales/metrics', {
      method: 'POST',
      body: JSON.stringify({ startDate, endDate })
    });
  }

  async getRevenueAnalytics(period: string) {
    return this.fetch('/analytics/revenue', {
      method: 'POST',
      body: JSON.stringify({ period })
    });
  }

  async getProductPerformance(productId: string) {
    return this.fetch(`/products/${productId}/performance`);
  }

  async getCustomerAnalytics(customerId: string) {
    return this.fetch(`/customers/${customerId}/analytics`);
  }

  // Sales Orders
  async getSalesOrders(filters?: any) {
    const queryParams = filters ? `?${new URLSearchParams(filters)}` : '';
    return this.fetch(`/sales-orders${queryParams}`);
  }

  async createSalesOrder(orderData: any) {
    return this.fetch('/sales-orders', {
      method: 'POST',
      body: JSON.stringify(orderData)
    });
  }

  // Inventory
  async getInventoryLevels(productIds: string[]) {
    return this.fetch('/inventory/levels', {
      method: 'POST',
      body: JSON.stringify({ productIds })
    });
  }

  // Reports
  async generateReport(reportType: string, parameters: any) {
    return this.fetch('/reports/generate', {
      method: 'POST',
      body: JSON.stringify({
        type: reportType,
        parameters
      })
    });
  }
}