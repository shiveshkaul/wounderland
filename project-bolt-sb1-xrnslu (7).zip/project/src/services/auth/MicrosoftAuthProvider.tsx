import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  PublicClientApplication,
  AccountInfo,
  Configuration,
  InteractionRequiredAuthError,
  PopupRequest,
  BrowserAuthError
} from '@azure/msal-browser';
import { Client } from '@microsoft/microsoft-graph-client';

// MSAL configuration
const msalConfig: Configuration = {
  auth: {
    clientId: import.meta.env.VITE_MICROSOFT_CLIENT_ID,
    authority: `https://login.microsoftonline.com/${import.meta.env.VITE_TENANT_ID}`,
    redirectUri: import.meta.env.VITE_MICROSOFT_REDIRECT_URI,
    postLogoutRedirectUri: import.meta.env.VITE_MICROSOFT_REDIRECT_URI,
    navigateToLoginRequestUrl: true
  },
  cache: {
    cacheLocation: 'sessionStorage',
    storeAuthStateInCookie: false
  },
  system: {
    allowNativeBroker: false,
    windowHashTimeout: 60000,
    iframeHashTimeout: 6000,
    loadFrameTimeout: 0
  }
};

// Define required scopes
const scopes = [
  'User.Read',
  'Sites.Read.All', 
  'Files.Read.All',
  'Calendars.Read',
  'Team.ReadBasic.All',
  'Tasks.Read'
];

const loginRequest: PopupRequest = {
  scopes,
  prompt: 'select_account'
};

export const MicrosoftAuthContext = createContext<any>(null);

let msalInstance: PublicClientApplication | null = null;

export function MicrosoftAuthProvider({ children }: { children: React.ReactNode }) {
  const [account, setAccount] = useState<AccountInfo | null>(null);
  const [graphClient, setGraphClient] = useState<Client | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    const initializeAuth = async () => {
      try {
        if (!msalInstance) {
          msalInstance = new PublicClientApplication(msalConfig);
          await msalInstance.initialize();
        }

        const accounts = msalInstance.getAllAccounts();
        if (accounts.length > 0) {
          setAccount(accounts[0]);
          setIsAuthenticated(true);
          await initializeGraphClient(accounts[0]);
        }
      } catch (error) {
        console.error('Failed to initialize MSAL:', error);
        setError(error as Error);
      }
    };

    initializeAuth();
  }, []);

  const initializeGraphClient = async (userAccount: AccountInfo) => {
    if (!msalInstance) return;

    try {
      const response = await msalInstance.acquireTokenSilent({
        scopes,
        account: userAccount
      });

      const client = Client.init({
        authProvider: (done) => done(null, response.accessToken)
      });

      setGraphClient(client);
    } catch (error) {
      if (error instanceof InteractionRequiredAuthError) {
        try {
          const response = await msalInstance.acquireTokenPopup({
            scopes,
            account: userAccount
          });
          const client = Client.init({
            authProvider: (done) => done(null, response.accessToken)
          });
          setGraphClient(client);
        } catch (err) {
          console.error('Error acquiring token:', err);
          setError(err as Error);
        }
      } else {
        console.error('Error initializing Graph client:', error);
        setError(error as Error);
      }
    }
  };

  const login = async () => {
    if (!msalInstance || isLoggingIn) return;
    
    setIsLoggingIn(true);
    setError(null);

    try {
      const loginResponse = await msalInstance.loginPopup(loginRequest);
      setAccount(loginResponse.account);
      setIsAuthenticated(true);
      await initializeGraphClient(loginResponse.account);
    } catch (error) {
      console.error('Login error:', error);
      if (error instanceof BrowserAuthError && error.errorCode === 'popup_window_error') {
        try {
          await msalInstance.loginRedirect(loginRequest);
        } catch (redirectError) {
          console.error('Redirect login error:', redirectError);
          setError(redirectError as Error);
        }
      }
      setError(error as Error);
    } finally {
      setIsLoggingIn(false);
    }
  };

  const logout = async () => {
    if (!msalInstance) return;

    try {
      await msalInstance.logoutPopup({
        account: account || undefined,
        postLogoutRedirectUri: msalConfig.auth.postLogoutRedirectUri
      });
      setAccount(null);
      setGraphClient(null);
      setIsAuthenticated(false);
    } catch (error) {
      console.error('Logout error:', error);
      try {
        await msalInstance.logoutRedirect();
      } catch (redirectError) {
        console.error('Redirect logout error:', redirectError);
        setError(redirectError as Error);
      }
    }
  };

  return (
    <MicrosoftAuthContext.Provider 
      value={{
        isAuthenticated,
        isLoggingIn,
        account,
        graphClient,
        error,
        login,
        logout
      }}
    >
      {children}
    </MicrosoftAuthContext.Provider>
  );
}

export function useMicrosoftAuth() {
  const context = useContext(MicrosoftAuthContext);
  if (!context) {
    throw new Error('useMicrosoftAuth must be used within a MicrosoftAuthProvider');
  }
  return context;
}