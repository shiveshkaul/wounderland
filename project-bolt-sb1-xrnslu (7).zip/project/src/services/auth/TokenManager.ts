import CryptoJS from 'crypto-js';

const ENCRYPTION_KEY = import.meta.env.VITE_ENCRYPTION_KEY || 'your-secure-key';

export class TokenManager {
  private static instance: TokenManager;
  private tokens: { [key: string]: string } = {};

  private constructor() {}

  static getInstance(): TokenManager {
    if (!TokenManager.instance) {
      TokenManager.instance = new TokenManager();
    }
    return TokenManager.instance;
  }

  setToken(service: string, token: string): void {
    // Encrypt token before storing
    const encryptedToken = CryptoJS.AES.encrypt(token, ENCRYPTION_KEY).toString();
    this.tokens[service] = encryptedToken;
    
    // Store in sessionStorage for persistence
    sessionStorage.setItem(`token_${service}`, encryptedToken);
  }

  getToken(service: string): string | null {
    // Try to get from memory first
    let encryptedToken = this.tokens[service];
    
    // If not in memory, try sessionStorage
    if (!encryptedToken) {
      encryptedToken = sessionStorage.getItem(`token_${service}`);
      if (encryptedToken) {
        this.tokens[service] = encryptedToken;
      }
    }

    if (!encryptedToken) return null;

    // Decrypt token
    try {
      const bytes = CryptoJS.AES.decrypt(encryptedToken, ENCRYPTION_KEY);
      return bytes.toString(CryptoJS.enc.Utf8);
    } catch (error) {
      console.error(`Error decrypting token for ${service}:`, error);
      return null;
    }
  }

  removeToken(service: string): void {
    delete this.tokens[service];
    sessionStorage.removeItem(`token_${service}`);
  }

  clearAllTokens(): void {
    this.tokens = {};
    Object.keys(sessionStorage)
      .filter(key => key.startsWith('token_'))
      .forEach(key => sessionStorage.removeItem(key));
  }
}