export class SAPAuthService {
  private baseUrl: string;
  private token: string | null = null;

  constructor() {
    this.baseUrl = import.meta.env.VITE_SAP_BASE_URL || '';
  }

  async login(): Promise<void> {
    try {
      const response = await fetch(`${this.baseUrl}/auth/token`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          client_id: import.meta.env.VITE_SAP_CLIENT_ID,
          client_secret: import.meta.env.VITE_SAP_CLIENT_SECRET,
          grant_type: 'client_credentials'
        })
      });

      if (!response.ok) {
        throw new Error('SAP authentication failed');
      }

      const data = await response.json();
      this.token = data.access_token;
      localStorage.setItem('sap_token', this.token);
    } catch (error) {
      console.error('SAP login error:', error);
      throw error;
    }
  }

  async logout(): Promise<void> {
    this.token = null;
    localStorage.removeItem('sap_token');
  }

  getToken(): string | null {
    return this.token || localStorage.getItem('sap_token');
  }
}