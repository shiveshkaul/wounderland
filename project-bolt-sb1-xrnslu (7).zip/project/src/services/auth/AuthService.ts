import { BrowserWindow } from '@electron/remote';
import { OAuth2Client } from 'google-auth-library';
import { PublicClientApplication, AuthenticationResult } from '@azure/msal-browser';

// Microsoft Authentication Configuration
const msalConfig = {
  auth: {
    clientId: process.env.VITE_MICROSOFT_CLIENT_ID || '',
    authority: `https://login.microsoftonline.com/${process.env.VITE_TENANT_ID}`,
    redirectUri: process.env.VITE_REDIRECT_URI
  }
};

// Salesforce Authentication Configuration
const salesforceConfig = {
  clientId: process.env.VITE_SALESFORCE_CLIENT_ID || '',
  clientSecret: process.env.VITE_SALESFORCE_CLIENT_SECRET || '',
  redirectUri: process.env.VITE_SALESFORCE_REDIRECT_URI || '',
  loginUrl: 'https://login.salesforce.com'
};

// SAP Authentication Configuration
const sapConfig = {
  clientId: process.env.VITE_SAP_CLIENT_ID || '',
  clientSecret: process.env.VITE_SAP_CLIENT_SECRET || '',
  redirectUri: process.env.VITE_SAP_REDIRECT_URI || '',
  authUrl: 'https://oauth.sap.com'
};

class AuthService {
  private msalInstance: PublicClientApplication;
  private salesforceTokens: { access_token?: string; refresh_token?: string } = {};
  private sapTokens: { access_token?: string; refresh_token?: string } = {};

  constructor() {
    this.msalInstance = new PublicClientApplication(msalConfig);
  }

  // Microsoft Authentication
  async loginWithMicrosoft(scopes: string[] = ['User.Read']): Promise<AuthenticationResult> {
    try {
      const response = await this.msalInstance.loginPopup({ scopes });
      return response;
    } catch (error) {
      console.error('Microsoft login failed:', error);
      throw error;
    }
  }

  // Salesforce Authentication
  async loginToSalesforce(): Promise<void> {
    const authUrl = `${salesforceConfig.loginUrl}/services/oauth2/authorize?` +
      `client_id=${salesforceConfig.clientId}&` +
      `redirect_uri=${encodeURIComponent(salesforceConfig.redirectUri)}&` +
      'response_type=code&' +
      'scope=api refresh_token';

    const authWindow = new BrowserWindow({
      width: 800,
      height: 600,
      webPreferences: {
        nodeIntegration: false
      }
    });

    authWindow.loadURL(authUrl);

    return new Promise((resolve, reject) => {
      authWindow.webContents.on('will-redirect', async (event, url) => {
        const code = new URL(url).searchParams.get('code');
        if (code) {
          try {
            const tokens = await this.getSalesforceTokens(code);
            this.salesforceTokens = tokens;
            authWindow.close();
            resolve();
          } catch (error) {
            reject(error);
          }
        }
      });
    });
  }

  // SAP Authentication
  async loginToSAP(): Promise<void> {
    const authUrl = `${sapConfig.authUrl}/oauth/authorize?` +
      `client_id=${sapConfig.clientId}&` +
      `redirect_uri=${encodeURIComponent(sapConfig.redirectUri)}&` +
      'response_type=code&' +
      'scope=api refresh_token';

    const authWindow = new BrowserWindow({
      width: 800,
      height: 600,
      webPreferences: {
        nodeIntegration: false
      }
    });

    authWindow.loadURL(authUrl);

    return new Promise((resolve, reject) => {
      authWindow.webContents.on('will-redirect', async (event, url) => {
        const code = new URL(url).searchParams.get('code');
        if (code) {
          try {
            const tokens = await this.getSAPTokens(code);
            this.sapTokens = tokens;
            authWindow.close();
            resolve();
          } catch (error) {
            reject(error);
          }
        }
      });
    });
  }

  private async getSalesforceTokens(code: string) {
    const response = await fetch(`${salesforceConfig.loginUrl}/services/oauth2/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        grant_type: 'authorization_code',
        client_id: salesforceConfig.clientId,
        client_secret: salesforceConfig.clientSecret,
        redirect_uri: salesforceConfig.redirectUri,
        code
      })
    });

    if (!response.ok) {
      throw new Error('Failed to get Salesforce tokens');
    }

    return response.json();
  }

  private async getSAPTokens(code: string) {
    const response = await fetch(`${sapConfig.authUrl}/oauth/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        grant_type: 'authorization_code',
        client_id: sapConfig.clientId,
        client_secret: sapConfig.clientSecret,
        redirect_uri: sapConfig.redirectUri,
        code
      })
    });

    if (!response.ok) {
      throw new Error('Failed to get SAP tokens');
    }

    return response.json();
  }

  // Token Management
  async refreshSalesforceToken(): Promise<void> {
    if (!this.salesforceTokens.refresh_token) {
      throw new Error('No refresh token available');
    }

    const response = await fetch(`${salesforceConfig.loginUrl}/services/oauth2/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        grant_type: 'refresh_token',
        client_id: salesforceConfig.clientId,
        client_secret: salesforceConfig.clientSecret,
        refresh_token: this.salesforceTokens.refresh_token
      })
    });

    if (!response.ok) {
      throw new Error('Failed to refresh Salesforce token');
    }

    const tokens = await response.json();
    this.salesforceTokens = { ...this.salesforceTokens, access_token: tokens.access_token };
  }

  async refreshSAPToken(): Promise<void> {
    if (!this.sapTokens.refresh_token) {
      throw new Error('No refresh token available');
    }

    const response = await fetch(`${sapConfig.authUrl}/oauth/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        grant_type: 'refresh_token',
        client_id: sapConfig.clientId,
        client_secret: sapConfig.clientSecret,
        refresh_token: this.sapTokens.refresh_token
      })
    });

    if (!response.ok) {
      throw new Error('Failed to refresh SAP token');
    }

    const tokens = await response.json();
    this.sapTokens = { ...this.sapTokens, access_token: tokens.access_token };
  }

  // Token Getters
  getSalesforceAccessToken(): string {
    return this.salesforceTokens.access_token || '';
  }

  getSAPAccessToken(): string {
    return this.sapTokens.access_token || '';
  }
}

export const authService = new AuthService();