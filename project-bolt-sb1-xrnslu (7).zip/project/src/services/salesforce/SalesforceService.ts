import jsforce from 'jsforce';
import 'events';
import 'buffer';
import 'process';
import 'stream-browserify';

export class SalesforceService {
  private conn: jsforce.Connection;

  constructor() {
    this.conn = new jsforce.Connection({
      oauth2: {
        loginUrl: import.meta.env.VITE_SALESFORCE_LOGIN_URL,
        clientId: import.meta.env.VITE_SALESFORCE_CLIENT_ID,
        clientSecret: import.meta.env.VITE_SALESFORCE_CLIENT_SECRET,
        redirectUri: `${window.location.origin}/auth/callback`
      }
    });
  }

  async login(username: string, password: string) {
    try {
      const userInfo = await new Promise((resolve, reject) => {
        this.conn.login(username, password, (err, userInfo) => {
          if (err) reject(err);
          resolve(userInfo);
        });
      });
      return userInfo;
    } catch (error) {
      console.error('Salesforce login error:', error);
      throw error;
    }
  }

  async query(soql: string) {
    try {
      return await this.conn.query(soql);
    } catch (error) {
      console.error('Salesforce query error:', error);
      throw error;
    }
  }

  async create(objectName: string, data: any) {
    try {
      return await this.conn.sobject(objectName).create(data);
    } catch (error) {
      console.error('Salesforce create error:', error);
      throw error;
    }
  }

  async update(objectName: string, data: any) {
    try {
      return await this.conn.sobject(objectName).update(data);
    } catch (error) {
      console.error('Salesforce update error:', error);
      throw error;
    }
  }

  async delete(objectName: string, id: string) {
    try {
      return await this.conn.sobject(objectName).destroy(id);
    } catch (error) {
      console.error('Salesforce delete error:', error);
      throw error;
    }
  }

  getAccessToken(): string {
    return this.conn.accessToken;
  }

  async logout() {
    try {
      await this.conn.logout();
    } catch (error) {
      console.error('Salesforce logout error:', error);
      throw error;
    }
  }
}