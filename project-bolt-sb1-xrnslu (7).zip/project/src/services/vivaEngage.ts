import { Announcement } from '../types';
import { VIVA_ENGAGE_URL, MOCK_DATA } from '../config/constants';

export const fetchVivaAnnouncements = async (): Promise<Announcement[]> => {
  try {
    return MOCK_DATA.announcements.map((announcement) => ({
      id: `viva-${announcement.id}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      title: announcement.title,
      description: announcement.description,
      category: announcement.category,
      date: announcement.date,
      source: 'viva',
      author: announcement.author,
      vivaLink: `${VIVA_ENGAGE_URL}/posts/${announcement.id}`
    }));
  } catch (error) {
    console.error('Error fetching Viva Engage announcements:', error);
    return [];
  }
};