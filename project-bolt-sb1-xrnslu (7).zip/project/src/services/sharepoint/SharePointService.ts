import { Client } from '@microsoft/microsoft-graph-client';

export class SharePointService {
  private graphClient: Client;

  constructor(graphClient: Client) {
    this.graphClient = graphClient;
  }

  async getProductUpdates(siteId: string, listId: string) {
    try {
      const response = await this.graphClient
        .api(`/sites/${siteId}/lists/${listId}/items`)
        .expand('fields')
        .get();

      return response.value.map((item: any) => ({
        id: item.id,
        title: item.fields.Title,
        description: item.fields.Description,
        releaseDate: item.fields.ReleaseDate,
        version: item.fields.Version,
        category: item.fields.Category,
        status: item.fields.Status,
        features: item.fields.Features?.split('\n') || [],
        images: item.fields.Images?.split(',') || [],
        documents: item.fields.Documents || [],
        links: item.fields.Links || []
      }));
    } catch (error) {
      console.error('Error fetching product updates:', error);
      throw error;
    }
  }

  async createProductUpdate(siteId: string, listId: string, update: any) {
    try {
      return await this.graphClient
        .api(`/sites/${siteId}/lists/${listId}/items`)
        .post({
          fields: {
            Title: update.title,
            Description: update.description,
            ReleaseDate: update.releaseDate,
            Version: update.version,
            Category: update.category,
            Status: update.status,
            Features: update.features?.join('\n'),
            Images: update.images?.join(','),
            Documents: update.documents,
            Links: update.links
          }
        });
    } catch (error) {
      console.error('Error creating product update:', error);
      throw error;
    }
  }
}