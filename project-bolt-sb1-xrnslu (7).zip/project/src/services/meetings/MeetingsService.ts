import { Client } from '@microsoft/microsoft-graph-client';
import { format } from 'date-fns';

export interface Meeting {
  id: string;
  title: string;
  date: string;
  duration: string;
  type: string;
  status: 'Completed' | 'Scheduled' | 'Cancelled';
  participants: string[];
  summary?: string;
  recording?: string;
  documents?: { name: string; url: string }[];
  tags: string[];
  priority: 'High' | 'Medium' | 'Low';
}

export class MeetingsService {
  private graphClient: Client;

  constructor(graphClient: Client) {
    this.graphClient = graphClient;
  }

  async getMeetings(startDate: Date, endDate: Date): Promise<Meeting[]> {
    try {
      const response = await this.graphClient
        .api('/me/calendar/events')
        .select('id,subject,start,end,attendees,bodyPreview,onlineMeeting')
        .filter(`start/dateTime ge '${format(startDate, "yyyy-MM-dd'T'HH:mm:ss'Z'")}' and end/dateTime le '${format(endDate, "yyyy-MM-dd'T'HH:mm:ss'Z'")}`)
        .orderby('start/dateTime')
        .get();

      return response.value.map(this.mapMeetingResponse);
    } catch (error) {
      console.error('Error fetching meetings:', error);
      throw error;
    }
  }

  async getMeetingRecordings(meetingId: string) {
    try {
      const response = await this.graphClient
        .api(`/me/onlineMeetings/${meetingId}/recordings`)
        .get();

      return response.value;
    } catch (error) {
      console.error('Error fetching meeting recordings:', error);
      throw error;
    }
  }

  async getMeetingTranscript(meetingId: string) {
    try {
      const response = await this.graphClient
        .api(`/me/onlineMeetings/${meetingId}/transcripts`)
        .get();

      return response.value;
    } catch (error) {
      console.error('Error fetching meeting transcript:', error);
      throw error;
    }
  }

  async getMeetingFiles(meetingId: string) {
    try {
      const response = await this.graphClient
        .api(`/me/onlineMeetings/${meetingId}/attachments`)
        .get();

      return response.value;
    } catch (error) {
      console.error('Error fetching meeting files:', error);
      throw error;
    }
  }

  private mapMeetingResponse(meeting: any): Meeting {
    return {
      id: meeting.id,
      title: meeting.subject,
      date: meeting.start.dateTime,
      duration: this.calculateDuration(meeting.start.dateTime, meeting.end.dateTime),
      type: meeting.onlineMeeting ? 'Online' : 'In-Person',
      status: this.determineStatus(meeting.start.dateTime, meeting.end.dateTime),
      participants: meeting.attendees.map((a: any) => a.emailAddress.name),
      summary: meeting.bodyPreview,
      recording: meeting.onlineMeeting?.joinUrl,
      tags: [],
      priority: 'Medium'
    };
  }

  private calculateDuration(start: string, end: string): string {
    const duration = new Date(end).getTime() - new Date(start).getTime();
    const hours = Math.floor(duration / (1000 * 60 * 60));
    const minutes = Math.floor((duration % (1000 * 60 * 60)) / (1000 * 60));
    return hours > 0 ? `${hours}h ${minutes}m` : `${minutes}m`;
  }

  private determineStatus(start: string, end: string): Meeting['status'] {
    const now = new Date().getTime();
    const startTime = new Date(start).getTime();
    const endTime = new Date(end).getTime();

    if (now < startTime) return 'Scheduled';
    if (now > endTime) return 'Completed';
    return 'Scheduled';
  }
}