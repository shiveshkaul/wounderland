import { API_BASE_URL } from '../config/constants';
import { Announcement, NotificationItem } from '../types';

export const fetchAnnouncements = async (): Promise<Announcement[]> => {
  try {
    const response = await fetch(new URL('/api/announcements', API_BASE_URL).toString());
    if (!response.ok) throw new Error('Failed to fetch announcements');
    return await response.json();
  } catch (error) {
    console.error('Error fetching announcements:', error);
    return [];
  }
};

export const createAnnouncement = async (announcement: Omit<Announcement, 'id' | 'date'>): Promise<Announcement> => {
  try {
    const response = await fetch(new URL('/api/announcements', API_BASE_URL).toString(), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        ...announcement,
        date: new Date().toISOString(),
      }),
    });
    if (!response.ok) throw new Error('Failed to create announcement');
    return await response.json();
  } catch (error) {
    console.error('Error creating announcement:', error);
    throw error;
  }
};

export const fetchNotifications = async (): Promise<NotificationItem[]> => {
  try {
    const response = await fetch(new URL('/api/notifications', API_BASE_URL).toString());
    if (!response.ok) throw new Error('Failed to fetch notifications');
    return await response.json();
  } catch (error) {
    console.error('Error fetching notifications:', error);
    return [];
  }
};