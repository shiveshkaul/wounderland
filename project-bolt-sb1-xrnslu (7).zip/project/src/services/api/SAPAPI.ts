import { authService } from '../auth/AuthService';

class SAPAPI {
  private baseUrl = 'https://your-sap-instance.com/api/v1';

  private async fetch(endpoint: string, options: RequestInit = {}) {
    const token = authService.getSAPAccessToken();
    
    try {
      const response = await fetch(`${this.baseUrl}${endpoint}`, {
        ...options,
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
          ...options.headers
        }
      });

      if (response.status === 401) {
        await authService.refreshSAPToken();
        return this.fetch(endpoint, options);
      }

      if (!response.ok) {
        throw new Error(`SAP API error: ${response.statusText}`);
      }

      return response.json();
    } catch (error) {
      console.error('SAP API error:', error);
      throw error;
    }
  }

  // Sales Performance
  async getSalesMetrics(params: { startDate: string; endDate: string }) {
    return this.fetch('/sales/metrics', {
      method: 'POST',
      body: JSON.stringify(params)
    });
  }

  async getProductPerformance(productId: string) {
    return this.fetch(`/products/${productId}/performance`);
  }

  async getRevenueAnalytics(params: { period: string }) {
    return this.fetch('/analytics/revenue', {
      method: 'POST',
      body: JSON.stringify(params)
    });
  }
}

export const sapAPI = new SAPAPI();