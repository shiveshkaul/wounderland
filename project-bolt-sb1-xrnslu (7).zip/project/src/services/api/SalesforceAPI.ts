import { authService } from '../auth/AuthService';

class SalesforceAPI {
  private baseUrl = 'https://your-instance.salesforce.com/services/data/v57.0';

  private async fetch(endpoint: string, options: RequestInit = {}) {
    const token = authService.getSalesforceAccessToken();
    
    try {
      const response = await fetch(`${this.baseUrl}${endpoint}`, {
        ...options,
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
          ...options.headers
        }
      });

      if (response.status === 401) {
        await authService.refreshSalesforceToken();
        return this.fetch(endpoint, options);
      }

      if (!response.ok) {
        throw new Error(`Salesforce API error: ${response.statusText}`);
      }

      return response.json();
    } catch (error) {
      console.error('Salesforce API error:', error);
      throw error;
    }
  }

  // Campaign Analytics
  async getCampaignMetrics(campaignId: string) {
    return this.fetch(`/sobjects/Campaign/${campaignId}`);
  }

  // Lead Management
  async getLeads(params: { status?: string; limit?: number } = {}) {
    const queryParams = new URLSearchParams(params as any).toString();
    return this.fetch(`/query?q=SELECT+Id,Name,Status+FROM+Lead${queryParams ? `&${queryParams}` : ''}`);
  }

  async createLead(data: any) {
    return this.fetch('/sobjects/Lead', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  }

  async updateLead(leadId: string, data: any) {
    return this.fetch(`/sobjects/Lead/${leadId}`, {
      method: 'PATCH',
      body: JSON.stringify(data)
    });
  }
}

export const salesforceAPI = new SalesforceAPI();