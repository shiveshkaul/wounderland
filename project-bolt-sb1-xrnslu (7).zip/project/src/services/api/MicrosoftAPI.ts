import { authService } from '../auth/AuthService';

class MicrosoftAPI {
  private graphBaseUrl = 'https://graph.microsoft.com/v1.0';

  private async fetch(endpoint: string, options: RequestInit = {}) {
    try {
      const msalResponse = await authService.loginWithMicrosoft(['User.Read']);
      
      const response = await fetch(`${this.graphBaseUrl}${endpoint}`, {
        ...options,
        headers: {
          'Authorization': `Bearer ${msalResponse.accessToken}`,
          'Content-Type': 'application/json',
          ...options.headers
        }
      });

      if (!response.ok) {
        throw new Error(`Microsoft API error: ${response.statusText}`);
      }

      return response.json();
    } catch (error) {
      console.error('Microsoft API error:', error);
      throw error;
    }
  }

  // Teams Integration
  async getTeamsChannels(teamId: string) {
    return this.fetch(`/teams/${teamId}/channels`);
  }

  async createTeamsMessage(channelId: string, message: any) {
    return this.fetch(`/teams/${channelId}/messages`, {
      method: 'POST',
      body: JSON.stringify(message)
    });
  }

  // SharePoint Integration
  async getSharePointFiles(siteId: string, libraryId: string) {
    return this.fetch(`/sites/${siteId}/drives/${libraryId}/root/children`);
  }

  async uploadSharePointFile(siteId: string, libraryId: string, file: File) {
    const response = await this.fetch(`/sites/${siteId}/drives/${libraryId}/root/children/${file.name}/createUploadSession`, {
      method: 'POST'
    });

    // Implement large file upload logic here
    return response;
  }

  // Planner Integration
  async getPlannerTasks(planId: string) {
    return this.fetch(`/planner/plans/${planId}/tasks`);
  }

  async createPlannerTask(planId: string, task: any) {
    return this.fetch(`/planner/tasks`, {
      method: 'POST',
      body: JSON.stringify({ planId, ...task })
    });
  }

  // Outlook Integration
  async getCalendarEvents(params: { startDateTime: string; endDateTime: string }) {
    return this.fetch(`/me/calendar/events?startDateTime=${params.startDateTime}&endDateTime=${params.endDateTime}`);
  }

  async createCalendarEvent(event: any) {
    return this.fetch('/me/calendar/events', {
      method: 'POST',
      body: JSON.stringify(event)
    });
  }

  // Power BI Integration
  async getPowerBIDashboards(workspaceId: string) {
    return this.fetch(`/powerbi/groups/${workspaceId}/dashboards`);
  }

  async getPowerBIReports(workspaceId: string) {
    return this.fetch(`/powerbi/groups/${workspaceId}/reports`);
  }
}

export const microsoftAPI = new MicrosoftAPI();