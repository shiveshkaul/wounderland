import { Client } from '@microsoft/microsoft-graph-client';

export class MicrosoftService {
  private graphClient: Client;

  constructor(graphClient: Client) {
    this.graphClient = graphClient;
  }

  // Meeting Summaries
  async getMeetings(startDate: Date, endDate: Date) {
    return this.graphClient
      .api('/me/calendar/events')
      .select('id,subject,start,end,attendees,bodyPreview,onlineMeeting')
      .filter(`start/dateTime ge '${startDate.toISOString()}' and end/dateTime le '${endDate.toISOString()}'`)
      .get();
  }

  async getMeetingRecordings(meetingId: string) {
    return this.graphClient
      .api(`/me/onlineMeetings/${meetingId}/recordings`)
      .get();
  }

  // SharePoint Documents
  async getSharePointDocuments(siteId: string, libraryId: string) {
    return this.graphClient
      .api(`/sites/${siteId}/drives/${libraryId}/root/children`)
      .get();
  }

  // Teams Integration
  async getTeamsChannels(teamId: string) {
    return this.graphClient
      .api(`/teams/${teamId}/channels`)
      .get();
  }

  async getTeamsMessages(teamId: string, channelId: string) {
    return this.graphClient
      .api(`/teams/${teamId}/channels/${channelId}/messages`)
      .get();
  }

  // Viva Engage
  async getVivaEngagePosts() {
    return this.graphClient
      .api('/sites/{viva-engage-site-id}/lists/{posts-list-id}/items')
      .expand('fields')
      .get();
  }

  // Analytics
  async getSalesAnalytics() {
    return this.graphClient
      .api('/reports/getEmailActivityCounts(period=\'D7\')')
      .get();
  }

  // Tasks/Planner
  async getPlannerTasks(planId: string) {
    return this.graphClient
      .api(`/planner/plans/${planId}/tasks`)
      .get();
  }

  // User Profile
  async getUserProfile() {
    return this.graphClient
      .api('/me')
      .select('id,displayName,jobTitle,mail,department')
      .get();
  }

  // Organization Data
  async getOrganizationInfo() {
    return this.graphClient
      .api('/organization')
      .get();
  }
}