import { useState, useCallback } from 'react';
import { SAPAuthService } from '../services/auth/SAPAuthService';

export function useSAPAuth() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const sapAuth = new SAPAuthService();

  const login = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      await sapAuth.login();
      setIsAuthenticated(true);
    } catch (err) {
      console.error('SAP login error:', err);
      setError('Failed to authenticate with SAP');
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const logout = useCallback(async () => {
    setLoading(true);
    try {
      await sapAuth.logout();
      setIsAuthenticated(false);
    } catch (err) {
      console.error('SAP logout error:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  return {
    isAuthenticated,
    login,
    logout,
    loading,
    error
  };
}