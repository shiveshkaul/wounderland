import { useState, useCallback } from 'react';
import { useMicrosoftAuth } from './useMicrosoftAuth';

interface SharePointDocument {
  id: string;
  name: string;
  webUrl: string;
  lastModifiedDateTime: string;
  size: number;
  createdBy: {
    user: {
      displayName: string;
    };
  };
  contentType: {
    name: string;
  };
  shared: {
    scope: string;
  };
  file?: {
    mimeType: string;
  };
  folder?: {
    childCount: number;
  };
}

export function useSharePointDirectories() {
  const { graphClient, isAuthenticated } = useMicrosoftAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchDirectoryContents = useCallback(async (directoryPath: string) => {
    if (!isAuthenticated || !graphClient) {
      setError('Not authenticated');
      return null;
    }

    setLoading(true);
    setError(null);

    try {
      // Get the site ID using the configured site URL
      const siteResponse = await graphClient
        .api('/sites')
        .filter(`webUrl eq '${import.meta.env.VITE_SHAREPOINT_SITE_URL}'`)
        .get();

      if (!siteResponse.value?.[0]) {
        throw new Error('SharePoint site not found');
      }

      const siteId = siteResponse.value[0].id;

      // Get the document library ID
      const drivesResponse = await graphClient
        .api(`/sites/${siteId}/drives`)
        .filter(`name eq '${import.meta.env.VITE_SHAREPOINT_LIBRARY_NAME}'`)
        .get();

      if (!drivesResponse.value?.[0]) {
        throw new Error('Document library not found');
      }

      const driveId = drivesResponse.value[0].id;

      // Fetch directory contents with detailed metadata
      const response = await graphClient
        .api(`/drives/${driveId}/root:${directoryPath}:/children`)
        .select([
          'id',
          'name',
          'webUrl',
          'lastModifiedDateTime',
          'size',
          'createdBy',
          'contentType',
          'shared',
          'file',
          'folder'
        ].join(','))
        .expand('createdBy,contentType,shared')
        .orderBy('lastModifiedDateTime desc')
        .get();

      return response.value as SharePointDocument[];
    } catch (err) {
      console.error('Error fetching directory contents:', err);
      setError(`Failed to fetch contents from ${directoryPath}`);
      return null;
    } finally {
      setLoading(false);
    }
  }, [graphClient, isAuthenticated]);

  // Map environment variables to directory functions
  const directories = {
    productUpdates: () => fetchDirectoryContents(import.meta.env.VITE_SHAREPOINT_PRODUCT_UPDATES_FOLDER),
    resources: () => fetchDirectoryContents(import.meta.env.VITE_SHAREPOINT_RESOURCES_FOLDER),
    sales: () => fetchDirectoryContents(import.meta.env.VITE_SHAREPOINT_SALES_FOLDER),
    meetings: () => fetchDirectoryContents(import.meta.env.VITE_SHAREPOINT_MEETINGS_FOLDER),
    announcements: () => fetchDirectoryContents(import.meta.env.VITE_SHAREPOINT_ANNOUNCEMENTS_FOLDER),
    tasks: () => fetchDirectoryContents(import.meta.env.VITE_SHAREPOINT_TASKS_FOLDER)
  };

  return {
    directories,
    loading,
    error,
    fetchDirectoryContents // Exposed for custom directory fetching
  };
}