import { useState, useCallback } from 'react';
import { SalesforceService } from '../services/salesforce/SalesforceService';

export function useSalesforce() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const salesforceService = new SalesforceService();

  const login = useCallback(async (username: string, password: string) => {
    setLoading(true);
    setError(null);
    try {
      const userInfo = await salesforceService.login(username, password);
      setIsAuthenticated(true);
      return userInfo;
    } catch (err) {
      console.error('Error logging into Salesforce:', err);
      setError('Failed to login to Salesforce');
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const query = useCallback(async (soql: string) => {
    if (!isAuthenticated) {
      setError('Not authenticated with Salesforce');
      return null;
    }

    setLoading(true);
    setError(null);
    try {
      return await salesforceService.query(soql);
    } catch (err) {
      console.error('Error querying Salesforce:', err);
      setError('Failed to query Salesforce');
      throw err;
    } finally {
      setLoading(false);
    }
  }, [isAuthenticated]);

  const logout = useCallback(async () => {
    if (!isAuthenticated) return;

    setLoading(true);
    setError(null);
    try {
      await salesforceService.logout();
      setIsAuthenticated(false);
    } catch (err) {
      console.error('Error logging out of Salesforce:', err);
      setError('Failed to logout from Salesforce');
      throw err;
    } finally {
      setLoading(false);
    }
  }, [isAuthenticated]);

  return {
    login,
    query,
    logout,
    loading,
    error,
    isAuthenticated
  };
}