import { useState, useCallback } from 'react';
import { useServiceIntegration } from './useServiceIntegration';

export function useSharePointIntegration() {
  const { microsoftIntegration, ensureAuth } = useServiceIntegration();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchDocuments = useCallback(async (siteId: string, libraryId: string) => {
    setLoading(true);
    setError(null);
    
    try {
      await ensureAuth('microsoft');
      if (!microsoftIntegration) {
        throw new Error('Microsoft integration not available');
      }
      
      const documents = await microsoftIntegration.getSharePointDocuments(siteId, libraryId);
      return documents;
    } catch (err) {
      console.error('Error fetching SharePoint documents:', err);
      setError('Failed to fetch documents from SharePoint');
      throw err;
    } finally {
      setLoading(false);
    }
  }, [microsoftIntegration, ensureAuth]);

  return {
    fetchDocuments,
    loading,
    error
  };
}