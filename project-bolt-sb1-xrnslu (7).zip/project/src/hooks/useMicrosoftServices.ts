import { useState, useCallback } from 'react';
import { useMicrosoftAuth } from './useMicrosoftAuth';
import { MicrosoftService } from '../services/microsoft/MicrosoftService';

export function useMicrosoftServices() {
  const { graphClient, isAuthenticated } = useMicrosoftAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const microsoftService = graphClient ? new MicrosoftService(graphClient) : null;

  const executeRequest = async <T>(request: () => Promise<T>): Promise<T | null> => {
    if (!isAuthenticated || !microsoftService) {
      setError('Not authenticated');
      return null;
    }

    setLoading(true);
    setError(null);

    try {
      const result = await request();
      return result;
    } catch (err) {
      console.error('Microsoft API error:', err);
      setError('Failed to fetch data');
      return null;
    } finally {
      setLoading(false);
    }
  };

  // Meeting Summaries
  const getMeetings = useCallback(async (startDate: Date, endDate: Date) => {
    return executeRequest(() => microsoftService!.getMeetings(startDate, endDate));
  }, [microsoftService]);

  // SharePoint Documents
  const getDocuments = useCallback(async (siteId: string, libraryId: string) => {
    return executeRequest(() => microsoftService!.getSharePointDocuments(siteId, libraryId));
  }, [microsoftService]);

  // Teams Integration
  const getTeamsChannels = useCallback(async (teamId: string) => {
    return executeRequest(() => microsoftService!.getTeamsChannels(teamId));
  }, [microsoftService]);

  // Analytics
  const getSalesAnalytics = useCallback(async () => {
    return executeRequest(() => microsoftService!.getSalesAnalytics());
  }, [microsoftService]);

  // Tasks
  const getPlannerTasks = useCallback(async (planId: string) => {
    return executeRequest(() => microsoftService!.getPlannerTasks(planId));
  }, [microsoftService]);

  return {
    loading,
    error,
    getMeetings,
    getDocuments,
    getTeamsChannels,
    getSalesAnalytics,
    getPlannerTasks
  };
}