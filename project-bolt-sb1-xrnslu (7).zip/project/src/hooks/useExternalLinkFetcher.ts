import { useState, useEffect } from 'react';
import { ExternalLink } from './useExternalLinks';

export function useExternalLinkFetcher(link: ExternalLink | null) {
  const [content, setContent] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchContent = async () => {
    if (!link) return;
    
    setLoading(true);
    setError(null);

    try {
      let response;
      
      switch (link.type) {
        case 'gdrive':
          // For Google Drive, we'll return the embed URL instead of fetching content
          response = {
            embedUrl: getGoogleDriveEmbedUrl(link.url),
            type: 'embed'
          };
          break;
        case 'onedrive':
          // For OneDrive, return the embed URL
          response = {
            embedUrl: getOneDriveEmbedUrl(link.url),
            type: 'embed'
          };
          break;
        case 'dropbox':
          // For Dropbox, return the preview URL
          response = {
            embedUrl: getDropboxPreviewUrl(link.url),
            type: 'embed'
          };
          break;
        default:
          response = await fetchGenericContent(link.url);
      }

      setContent(response);
    } catch (err) {
      console.error(`Error handling content from ${link.type}:`, err);
      setError(`Failed to handle content from ${link.type}`);
    } finally {
      setLoading(false);
    }
  };

  // Helper functions to get embed URLs
  const getGoogleDriveEmbedUrl = (url: string): string => {
    const fileId = extractGoogleDriveFileId(url);
    return `https://drive.google.com/file/d/${fileId}/preview`;
  };

  const getOneDriveEmbedUrl = (url: string): string => {
    return `https://view.officeapps.live.com/op/embed.aspx?src=${encodeURIComponent(url)}`;
  };

  const getDropboxPreviewUrl = (url: string): string => {
    return url.replace('www.dropbox.com', 'www.dropbox.com/preview');
  };

  // Fetch generic content
  const fetchGenericContent = async (url: string) => {
    const response = await fetch(url);
    
    if (!response.ok) {
      throw new Error('Failed to fetch content');
    }

    const contentType = response.headers.get('content-type');
    
    if (contentType?.includes('application/json')) {
      const data = await response.json();
      return { data, type: 'json' };
    } else if (contentType?.includes('text/')) {
      const text = await response.text();
      return { data: text, type: 'text' };
    } else if (contentType?.includes('image/')) {
      const blob = await response.blob();
      return { data: URL.createObjectURL(blob), type: 'image' };
    } else {
      return { embedUrl: url, type: 'embed' };
    }
  };

  // Helper function to extract Google Drive file ID
  const extractGoogleDriveFileId = (url: string): string => {
    const match = url.match(/[-\w]{25,}/);
    return match ? match[0] : '';
  };

  // Fetch content when link changes
  useEffect(() => {
    if (link) {
      fetchContent();
    }
  }, [link?.id, link?.url]);

  return {
    content,
    loading,
    error,
    refetch: fetchContent
  };
}