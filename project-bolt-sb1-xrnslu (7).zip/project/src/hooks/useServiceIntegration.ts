import { useState, useEffect } from 'react';
import { useMicrosoftAuth } from '../services/auth/MicrosoftAuthProvider';
import { MicrosoftIntegration } from '../services/integrations/MicrosoftIntegration';

export function useServiceIntegration() {
  const { graphClient, isAuthenticated, login } = useMicrosoftAuth();
  const [microsoftIntegration, setMicrosoftIntegration] = useState<MicrosoftIntegration | null>(null);

  useEffect(() => {
    if (graphClient) {
      const integration = new MicrosoftIntegration(graphClient);
      setMicrosoftIntegration(integration);
    }
  }, [graphClient]);

  const ensureAuth = async (service: 'microsoft') => {
    if (!isAuthenticated) {
      await login();
    }
  };

  return {
    microsoftIntegration,
    ensureAuth
  };
}