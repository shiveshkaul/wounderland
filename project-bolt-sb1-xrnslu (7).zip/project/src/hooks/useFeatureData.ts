import { useCallback } from 'react';
import { useMicrosoftServices } from './useMicrosoftServices';

export function useFeatureData() {
  const {
    getMeetings,
    getDocuments,
    getTeamsChannels,
    getSalesAnalytics,
    getPlannerTasks,
    error,
    loading
  } = useMicrosoftServices();

  // Fetch SharePoint documents with auto-discovery
  const fetchSharePointDocuments = useCallback(async () => {
    try {
      // First get sites matching name
      const sites = await getDocuments('sites?search=' + import.meta.env.VITE_SHAREPOINT_SITE_NAME);
      if (sites?.value?.[0]?.id) {
        const siteId = sites.value[0].id;
        // Then get documents from the site
        return getDocuments(`sites/${siteId}/drive/root/children`);
      }
    } catch (err) {
      console.error('Error fetching SharePoint docs:', err);
      return null;
    }
  }, [getDocuments]);

  // Fetch Teams data with auto-discovery
  const fetchTeamsData = useCallback(async () => {
    try {
      // Get teams/groups matching name
      const groups = await getTeamsChannels('groups?$filter=displayName eq \'' + import.meta.env.VITE_TEAMS_GROUP_NAME + '\'');
      if (groups?.value?.[0]?.id) {
        const teamId = groups.value[0].id;
        return getTeamsChannels(`teams/${teamId}/channels`);
      }
    } catch (err) {
      console.error('Error fetching Teams data:', err);
      return null; 
    }
  }, [getTeamsChannels]);

  // Fetch meetings for last 30 days
  const fetchMeetingSummaries = useCallback(async () => {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - 30);
    const endDate = new Date();
    return getMeetings(startDate, endDate);
  }, [getMeetings]);

  // Fetch analytics data
  const fetchSalesAnalytics = useCallback(async () => {
    return getSalesAnalytics();
  }, [getSalesAnalytics]);

  // Fetch tasks
  const fetchTasks = useCallback(async () => {
    try {
      const plans = await getPlannerTasks('planner/plans');
      if (plans?.value?.[0]?.id) {
        return getPlannerTasks(`planner/plans/${plans.value[0].id}/tasks`);
      }
    } catch (err) {
      console.error('Error fetching tasks:', err);
      return null;
    }
  }, [getPlannerTasks]);

  return {
    fetchMeetingSummaries,
    fetchSharePointDocuments,
    fetchTeamsData,
    fetchSalesAnalytics,
    fetchTasks,
    error,
    loading
  };
}