import { useState, useCallback } from 'react';
import { useMicrosoftAuth } from './useMicrosoftAuth';
import { MeetingsService, Meeting } from '../services/meetings/MeetingsService';

export function useMeetings() {
  const { graphClient, isAuthenticated } = useMicrosoftAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchMeetings = useCallback(async (startDate: Date, endDate: Date) => {
    if (!isAuthenticated || !graphClient) {
      setError('Not authenticated');
      return [];
    }

    setLoading(true);
    setError(null);

    try {
      const meetingsService = new MeetingsService(graphClient);
      const meetings = await meetingsService.getMeetings(startDate, endDate);
      return meetings;
    } catch (err) {
      console.error('Error fetching meetings:', err);
      setError('Failed to fetch meetings');
      return [];
    } finally {
      setLoading(false);
    }
  }, [graphClient, isAuthenticated]);

  const fetchMeetingDetails = useCallback(async (meetingId: string) => {
    if (!isAuthenticated || !graphClient) {
      setError('Not authenticated');
      return null;
    }

    setLoading(true);
    setError(null);

    try {
      const meetingsService = new MeetingsService(graphClient);
      const [recordings, transcript, files] = await Promise.all([
        meetingsService.getMeetingRecordings(meetingId),
        meetingsService.getMeetingTranscript(meetingId),
        meetingsService.getMeetingFiles(meetingId)
      ]);

      return {
        recordings,
        transcript,
        files
      };
    } catch (err) {
      console.error('Error fetching meeting details:', err);
      setError('Failed to fetch meeting details');
      return null;
    } finally {
      setLoading(false);
    }
  }, [graphClient, isAuthenticated]);

  return {
    fetchMeetings,
    fetchMeetingDetails,
    loading,
    error
  };
}