import { useMicrosoftAuth as useAuth } from '../services/auth/MicrosoftAuthProvider';

export const useMicrosoftAuth = useAuth;