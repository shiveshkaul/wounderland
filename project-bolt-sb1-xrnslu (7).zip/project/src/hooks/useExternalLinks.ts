import { useState, useEffect } from 'react';

export interface ExternalLink {
  id: string;
  title: string;
  url: string;
  type: 'gdrive' | 'onedrive' | 'dropbox' | 'generic';
  category: string;
  description?: string;
  lastModified?: string;
}

// This would typically come from your backend/database
const MOCK_EXTERNAL_LINKS: ExternalLink[] = [
  {
    id: 'ext-1',
    title: 'Product Catalog 2024',
    url: 'https://docs.google.com/spreadsheets/d/your-spreadsheet-id',
    type: 'gdrive',
    category: 'productUpdates',
    description: 'Complete product catalog with pricing',
    lastModified: new Date().toISOString()
  }
];

export function useExternalLinks() {
  const [links, setLinks] = useState<Record<string, ExternalLink[]>>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchLinks = async () => {
    setLoading(true);
    try {
      // In a real app, this would be an API call
      const fetchedLinks = MOCK_EXTERNAL_LINKS;
      
      // Group links by category
      const groupedLinks = fetchedLinks.reduce((acc, link) => {
        if (!acc[link.category]) {
          acc[link.category] = [];
        }
        acc[link.category].push(link);
        return acc;
      }, {} as Record<string, ExternalLink[]>);

      setLinks(groupedLinks);
      setError(null);
    } catch (err) {
      console.error('Error fetching external links:', err);
      setError('Failed to load external links');
    } finally {
      setLoading(false);
    }
  };

  const addLink = async (link: Omit<ExternalLink, 'id'>) => {
    setLoading(true);
    try {
      // In a real app, this would be an API call
      const newLink: ExternalLink = {
        ...link,
        id: `ext-${Date.now()}`,
        lastModified: new Date().toISOString()
      };

      setLinks(prev => ({
        ...prev,
        [link.category]: [...(prev[link.category] || []), newLink]
      }));

      setError(null);
      return newLink;
    } catch (err) {
      console.error('Error adding external link:', err);
      setError('Failed to add external link');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const removeLink = async (id: string, category: string) => {
    setLoading(true);
    try {
      // In a real app, this would be an API call
      setLinks(prev => ({
        ...prev,
        [category]: prev[category]?.filter(link => link.id !== id) || []
      }));
      setError(null);
    } catch (err) {
      console.error('Error removing external link:', err);
      setError('Failed to remove external link');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLinks();
  }, []);

  return {
    links,
    loading,
    error,
    addLink,
    removeLink,
    refreshLinks: fetchLinks
  };
}