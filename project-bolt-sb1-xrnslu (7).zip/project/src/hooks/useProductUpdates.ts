import { useState, useCallback } from 'react';
import { useMicrosoftAuth } from './useMicrosoftAuth';
import { SharePointService } from '../services/sharepoint/SharePointService';

export function useProductUpdates() {
  const { graphClient, isAuthenticated } = useMicrosoftAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchUpdates = useCallback(async () => {
    if (!isAuthenticated || !graphClient) {
      setError('Not authenticated');
      return [];
    }

    setLoading(true);
    setError(null);

    try {
      const sharePointService = new SharePointService(graphClient);
      const updates = await sharePointService.getProductUpdates(
        import.meta.env.VITE_SHAREPOINT_SITE_ID,
        import.meta.env.VITE_PRODUCT_UPDATES_LIST_ID
      );
      return updates;
    } catch (err) {
      console.error('Error fetching product updates:', err);
      setError('Failed to fetch product updates');
      return [];
    } finally {
      setLoading(false);
    }
  }, [graphClient, isAuthenticated]);

  const createUpdate = useCallback(async (update: any) => {
    if (!isAuthenticated || !graphClient) {
      setError('Not authenticated');
      return null;
    }

    setLoading(true);
    setError(null);

    try {
      const sharePointService = new SharePointService(graphClient);
      const result = await sharePointService.createProductUpdate(
        import.meta.env.VITE_SHAREPOINT_SITE_ID,
        import.meta.env.VITE_PRODUCT_UPDATES_LIST_ID,
        update
      );
      return result;
    } catch (err) {
      console.error('Error creating product update:', err);
      setError('Failed to create product update');
      return null;
    } finally {
      setLoading(false);
    }
  }, [graphClient, isAuthenticated]);

  return {
    fetchUpdates,
    createUpdate,
    loading,
    error
  };
}