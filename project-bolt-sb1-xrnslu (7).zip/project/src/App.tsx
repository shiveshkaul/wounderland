import React from 'react';
import { BrowserRouter } from 'react-router-dom';
import { useStore } from './store/useStore';
import Layout from './components/layout/Layout';
import AppRoutes from './routes';
import { FloatingAnnouncements } from './components/announcements/FloatingAnnouncements';
import { MicrosoftAuthProvider } from './services/auth/MicrosoftAuthProvider';
import { ErrorBoundary } from './components/auth/ErrorBoundary';

export default function App() {
  const { darkMode } = useStore();

  return (
    <div className={darkMode ? 'dark' : ''}>
      <ErrorBoundary>
        <React.Suspense fallback={
          <div className="flex items-center justify-center min-h-screen">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
          </div>
        }>
          <MicrosoftAuthProvider>
            <BrowserRouter>
              <Layout>
                <AppRoutes />
                <FloatingAnnouncements />
              </Layout>
            </BrowserRouter>
          </MicrosoftAuthProvider>
        </React.Suspense>
      </ErrorBoundary>
    </div>
  );
}