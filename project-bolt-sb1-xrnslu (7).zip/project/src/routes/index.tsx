import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Dashboard from '../components/dashboard/Dashboard';
import Calendar from '../components/pages/Calendar';
import Tasks from '../components/pages/TaskTracking';
import Announcements from '../components/pages/Announcements';
import Analytics from '../components/pages/marketing/CampaignAnalytics';
import Resources from '../components/pages/Resources';
import Awards from '../components/pages/Awards';
import Profile from '../components/pages/Profile';
import Settings from '../components/pages/Settings';
import SalesPerformance from '../components/pages/SalesPerformance';
import ProductUpdates from '../components/pages/marketing/ProductUpdates';
import Communications from '../components/pages/marketing/Communications';
import MeetingSummaries from '../components/pages/MeetingSummaries';

export default function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Dashboard />} />
      <Route path="/calendar" element={<Calendar />} />
      <Route path="/tasks" element={<Tasks />} />
      <Route path="/announcements" element={<Announcements />} />
      <Route path="/analytics" element={<Analytics />} />
      <Route path="/resources" element={<Resources />} />
      <Route path="/awards" element={<Awards />} />
      <Route path="/profile" element={<Profile />} />
      <Route path="/settings" element={<Settings />} />
      <Route path="/sales" element={<SalesPerformance />} />
      <Route path="/products" element={<ProductUpdates />} />
      <Route path="/communications" element={<Communications />} />
      <Route path="/meetings" element={<MeetingSummaries />} />
    </Routes>
  );
}