export const API_BASE_URL = 'https://api.wounderland.com';
export const VIVA_ENGAGE_URL = 'https://viva.microsoft.com';

// Integration URLs
export const INTEGRATION_URLS = {
  // Microsoft Services
  teams: 'https://teams.microsoft.com',
  sharepoint: 'https://sharepoint.company.com',
  planner: 'https://tasks.office.com',
  onedrive: 'https://onedrive.live.com',
  outlook: 'https://outlook.office.com',
  powerbi: 'https://app.powerbi.com',
  stream: 'https://web.microsoftstream.com',
  
  // Salesforce
  salesforce: 'https://login.salesforce.com',
  salesforceAnalytics: 'https://analytics.salesforce.com',
  salesforceLeads: 'https://company.salesforce.com/leads',
  
  // SAP
  sap: 'https://sap.company.com',
  sapAnalytics: 'https://analytics.sap.company.com',
  
  // Other Services
  powerAutomate: 'https://flow.microsoft.com'
};

// Service Integration Config
export const SERVICE_CONFIG = {
  teams: {
    channelId: 'marketing-announcements',
    workspaceId: 'marketing-workspace'
  },
  sharepoint: {
    siteId: 'marketing-hub',
    libraryId: 'documents'
  },
  planner: {
    planId: 'marketing-tasks',
    groupId: 'marketing-team'
  }
};

// Mock Data for Development
export const MOCK_DATA = {
  announcements: [
    {
      id: '1',
      title: 'New Marketing Campaign Launch',
      description: 'Launching our Q2 wound care product campaign',
      category: 'Marketing Update',
      date: new Date().toISOString(),
      source: 'internal',
      author: 'Peter Schuck'
    },
    {
      id: '2',
      title: 'Upcoming Trade Show',
      description: 'Preparing for the International Wound Care Expo',
      category: 'Events',
      date: new Date(Date.now() + 86400000).toISOString(),
      source: 'internal',
      author: 'Marketing Team'
    }
  ],
  notifications: [
    {
      id: '1',
      title: 'Campaign Performance Update',
      message: 'Q1 campaign metrics now available',
      type: 'info',
      read: false,
      date: new Date().toISOString()
    },
    {
      id: '2',
      title: 'New Lead Assignment',
      message: 'High-priority lead assigned to your team',
      type: 'success',
      read: false,
      date: new Date().toISOString()
    }
  ]
};