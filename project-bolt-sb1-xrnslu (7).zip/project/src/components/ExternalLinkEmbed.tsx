import React from 'react';
import { ExternalLink } from '../hooks/useExternalLinks';

interface Props {
  link: ExternalLink;
  className?: string;
}

export function ExternalLinkEmbed({ link, className = '' }: Props) {
  const getEmbedUrl = (url: string, type: ExternalLink['type']): string => {
    try {
      const urlObj = new URL(url);
      
      switch (type) {
        case 'gdrive':
          // Convert Google Drive view URL to embed URL
          if (url.includes('spreadsheets/d/')) {
            return url.replace('/edit', '/preview');
          } else if (url.includes('document/d/')) {
            return url.replace('/edit', '/preview');
          } else if (url.includes('presentation/d/')) {
            return url.replace('/edit', '/preview');
          }
          return url;

        case 'onedrive':
          // Convert OneDrive URL to embed URL
          return `https://view.officeapps.live.com/op/embed.aspx?src=${encodeURIComponent(url)}`;

        case 'dropbox':
          // Convert Dropbox URL to embed URL
          return url.replace('www.dropbox.com', 'www.dropbox.com/preview');

        default:
          return url;
      }
    } catch (error) {
      console.error('Error parsing URL:', error);
      return url;
    }
  };

  const embedUrl = getEmbedUrl(link.url, link.type);

  return (
    <div className={`relative overflow-hidden rounded-lg ${className}`}>
      <iframe
        src={embedUrl}
        title={link.title}
        className="w-full h-full min-h-[500px] border-0"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
        allowFullScreen
      />
    </div>
  );
}