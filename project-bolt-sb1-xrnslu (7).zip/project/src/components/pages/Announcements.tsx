import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../../store/useStore';
import { Bell, Search, Filter, Plus, Calendar, MessageSquare, RefreshCw, Link as LinkIcon } from 'lucide-react';
import { fetchVivaAnnouncements } from '../../services/vivaEngage';
import type { Announcement } from '../../types';

const generateUniqueId = (prefix: string, id: string) => 
  `${prefix}-${id}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

export default function Announcements() {
  const navigate = useNavigate();
  const { announcements, setAnnouncements } = useStore();
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [vivaAnnouncements, setVivaAnnouncements] = useState<Announcement[]>([]);

  useEffect(() => {
    loadVivaAnnouncements();
  }, []);

  const loadVivaAnnouncements = async () => {
    setLoading(true);
    try {
      const vivaData = await fetchVivaAnnouncements();
      setVivaAnnouncements(vivaData);
    } catch (error) {
      console.error('Error fetching Viva Engage announcements:', error);
    } finally {
      setLoading(false);
    }
  };

  const allAnnouncements = [
    ...announcements.map(ann => ({
      ...ann,
      uniqueId: generateUniqueId('internal', ann.id)
    })),
    ...vivaAnnouncements.map(ann => ({
      ...ann,
      uniqueId: generateUniqueId('viva', ann.id)
    }))
  ];

  const filteredAnnouncements = allAnnouncements.filter(announcement => {
    const matchesSearch = announcement.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         announcement.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || announcement.category.toLowerCase() === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const categories = ['All', 'Clinical Update', 'Technical Update', 'Events', 'General'];

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="bg-gradient-to-br from-blue-600 to-blue-800 dark:from-gray-800 dark:to-gray-900 rounded-2xl p-8 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2">Announcements</h1>
              <p className="text-blue-100 dark:text-gray-300">
                Company updates and news
              </p>
            </div>
            <div className="p-4 bg-white/10 rounded-xl">
              <Bell className="h-8 w-8" />
            </div>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm mb-6">
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex flex-wrap gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <input
                  type="text"
                  placeholder="Search announcements..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700"
                />
              </div>
            </div>
            <div className="flex gap-4">
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700"
              >
                {categories.map(category => (
                  <option key={category} value={category.toLowerCase()}>{category}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="p-4 flex justify-between items-center">
          <div className="flex gap-4">
            <button
              onClick={() => navigate('/new-announcement')}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              <Plus className="h-5 w-5" />
              New Announcement
            </button>
            <button
              onClick={loadVivaAnnouncements}
              className="flex items-center gap-2 px-4 py-2 text-blue-600 border border-blue-600 rounded-lg hover:bg-blue-50 dark:hover:bg-blue-900/20"
            >
              <RefreshCw className="h-5 w-5" />
              Sync Viva
            </button>
          </div>
          <div className="flex gap-2">
            <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
              <Filter className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Announcements List */}
      <div className="space-y-4">
        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
            <p className="mt-4 text-gray-600 dark:text-gray-400">Syncing with Viva Engage...</p>
          </div>
        ) : filteredAnnouncements.length === 0 ? (
          <div className="text-center py-12 bg-white dark:bg-gray-800 rounded-lg">
            <p className="text-gray-500 dark:text-gray-400">No announcements found</p>
          </div>
        ) : (
          filteredAnnouncements.map((announcement) => (
            <div
              key={announcement.uniqueId}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-semibold">{announcement.title}</h3>
                    {announcement.source === 'viva' && (
                      <span className="flex items-center gap-1 text-xs px-2 py-1 bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 rounded-full">
                        <LinkIcon className="w-3 h-3" />
                        Viva Engage
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                    {announcement.category}
                  </p>
                  <p className="text-gray-700 dark:text-gray-300 mt-4">
                    {announcement.description}
                  </p>
                  <div className="flex items-center gap-4 mt-4 text-sm text-gray-500">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      {new Date(announcement.date).toLocaleDateString()}
                    </div>
                    <div className="flex items-center gap-2">
                      <MessageSquare className="h-4 w-4" />
                      {announcement.author}
                    </div>
                  </div>
                  {announcement.vivaLink && (
                    <a
                      href={announcement.vivaLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 mt-4 text-sm text-blue-600 hover:underline"
                    >
                      View in Viva Engage
                      <LinkIcon className="w-4 h-4" />
                    </a>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}