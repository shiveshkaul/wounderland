import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  Users,
  Package,
  ChevronLeft,
  Calendar,
  Filter,
  Download,
  RefreshCw
} from 'lucide-react';

const salesData = [
  { month: 'Jan', revenue: 45000, target: 42000, units: 1200 },
  { month: 'Feb', revenue: 52000, target: 45000, units: 1350 },
  { month: 'Mar', revenue: 48000, target: 47000, units: 1100 },
  { month: 'Apr', revenue: 61000, target: 50000, units: 1500 },
  { month: 'May', revenue: 55000, target: 52000, units: 1250 },
  { month: 'Jun', revenue: 67000, target: 55000, units: 1600 }
];

const productPerformance = [
  { name: 'Advanced Dressings', value: 35, color: '#3B82F6' },
  { name: 'Compression Systems', value: 25, color: '#10B981' },
  { name: 'Wound Cleansers', value: 20, color: '#6366F1' },
  { name: 'Bioactive Dressings', value: 15, color: '#F59E0B' },
  { name: 'Other Products', value: 5, color: '#6B7280' }
];

const topCustomers = [
  { name: 'City General Hospital', revenue: 125000, growth: 12.5 },
  { name: 'MedCare Clinic Network', revenue: 98000, growth: 8.2 },
  { name: 'Regional Medical Center', revenue: 85000, growth: 15.3 },
  { name: 'Wellness Healthcare Group', revenue: 76000, growth: -2.1 }
];

interface KPICardProps {
  title: string;
  value: string;
  change: string;
  icon: React.ElementType;
  trend: 'up' | 'down';
}

const KPICard: React.FC<KPICardProps> = ({ title, value, change, icon: Icon, trend }) => (
  <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
    <div className="flex items-center justify-between mb-4">
      <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
        <Icon className="h-6 w-6 text-blue-600 dark:text-blue-400" />
      </div>
      <span className={`flex items-center text-sm ${
        trend === 'up' ? 'text-green-600' : 'text-red-600'
      }`}>
        {trend === 'up' ? <TrendingUp className="h-4 w-4 mr-1" /> : <TrendingDown className="h-4 w-4 mr-1" />}
        {change}%
      </span>
    </div>
    <h3 className="text-gray-600 dark:text-gray-400 text-sm font-medium mb-2">{title}</h3>
    <p className="text-2xl font-bold">{value}</p>
  </div>
);

export default function SalesPerformance() {
  const navigate = useNavigate();
  const [timeframe, setTimeframe] = useState('6M');

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex items-center gap-4 mb-8">
        <button
          onClick={() => navigate('/')}
          className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        <h1 className="text-2xl font-bold">Sales Performance</h1>
      </div>

      {/* Controls */}
      <div className="flex flex-wrap gap-4 mb-8">
        <div className="flex items-center gap-2 bg-white dark:bg-gray-800 rounded-lg p-2">
          <button
            className={`px-4 py-2 rounded-md ${
              timeframe === '1M' ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-600' : ''
            }`}
            onClick={() => setTimeframe('1M')}
          >
            1M
          </button>
          <button
            className={`px-4 py-2 rounded-md ${
              timeframe === '6M' ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-600' : ''
            }`}
            onClick={() => setTimeframe('6M')}
          >
            6M
          </button>
          <button
            className={`px-4 py-2 rounded-md ${
              timeframe === '1Y' ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-600' : ''
            }`}
            onClick={() => setTimeframe('1Y')}
          >
            1Y
          </button>
          <button
            className={`px-4 py-2 rounded-md ${
              timeframe === 'ALL' ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-600' : ''
            }`}
            onClick={() => setTimeframe('ALL')}
          >
            ALL
          </button>
        </div>

        <div className="flex gap-2 ml-auto">
          <button className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-gray-800 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700">
            <Calendar className="h-5 w-5" />
            Custom Range
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-gray-800 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700">
            <Filter className="h-5 w-5" />
            Filters
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-gray-800 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700">
            <Download className="h-5 w-5" />
            Export
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-gray-800 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700">
            <RefreshCw className="h-5 w-5" />
            Refresh
          </button>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <KPICard
          title="Total Revenue"
          value="$328,500"
          change="15.3"
          icon={DollarSign}
          trend="up"
        />
        <KPICard
          title="Total Units Sold"
          value="8,000"
          change="12.1"
          icon={Package}
          trend="up"
        />
        <KPICard
          title="Active Customers"
          value="245"
          change="8.5"
          icon={Users}
          trend="up"
        />
        <KPICard
          title="Average Order Value"
          value="$1,850"
          change="-2.3"
          icon={TrendingUp}
          trend="down"
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6">
          <h3 className="text-lg font-semibold mb-6">Revenue vs Target</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={salesData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="revenue" stroke="#3B82F6" name="Revenue" />
              <Line type="monotone" dataKey="target" stroke="#EF4444" name="Target" strokeDasharray="5 5" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg p-6">
          <h3 className="text-lg font-semibold mb-6">Units Sold by Month</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={salesData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="units" fill="#3B82F6" name="Units Sold" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Product Performance */}
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6">
          <h3 className="text-lg font-semibold mb-6">Product Performance</h3>
          <div className="flex items-center justify-between">
            <ResponsiveContainer width="60%" height={300}>
              <PieChart>
                <Pie
                  data={productPerformance}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  label
                >
                  {productPerformance.map((entry, index) => (
                    <Cell key={index} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="w-[40%] space-y-4">
              {productPerformance.map((product, index) => (
                <div key={index} className="flex items-center gap-2">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: product.color }}
                  />
                  <span className="text-sm">{product.name}</span>
                  <span className="text-sm font-medium ml-auto">{product.value}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Top Customers */}
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6">
          <h3 className="text-lg font-semibold mb-6">Top Customers</h3>
          <div className="space-y-4">
            {topCustomers.map((customer, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div>
                  <h4 className="font-medium">{customer.name}</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    ${customer.revenue.toLocaleString()}
                  </p>
                </div>
                <span className={`flex items-center ${
                  customer.growth >= 0 ? 'text-green-600' : 'text-red-600'
                }`}>
                  {customer.growth >= 0 ? (
                    <TrendingUp className="h-4 w-4 mr-1" />
                  ) : (
                    <TrendingDown className="h-4 w-4 mr-1" />
                  )}
                  {Math.abs(customer.growth)}%
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}