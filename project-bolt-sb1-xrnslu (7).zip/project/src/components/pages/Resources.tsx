import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ChevronLeft,
  Search,
  Filter,
  Download,
  FileText,
  Book,
  Video,
  Link as LinkIcon,
  Star,
  Clock,
  Plus,
  RefreshCw,
  Folder,
  BookOpen
} from 'lucide-react';

interface Resource {
  id: string;
  title: string;
  type: 'document' | 'video' | 'link' | 'guide';
  category: string;
  description: string;
  author: string;
  dateAdded: string;
  lastAccessed?: string;
  tags: string[];
  featured: boolean;
  downloadUrl?: string;
  fileSize?: string;
}

const MOCK_RESOURCES: Resource[] = [
  {
    id: 'RES-001',
    title: 'Advanced Wound Care Protocol 2024',
    type: 'document',
    category: 'Clinical Guidelines',
    description: 'Comprehensive guide for advanced wound care procedures',
    author: 'Medical Advisory Board',
    dateAdded: '2024-03-01',
    lastAccessed: '2024-03-14',
    tags: ['protocol', 'wound-care', 'clinical'],
    featured: true,
    downloadUrl: '#',
    fileSize: '2.4 MB'
  },
  {
    id: 'RES-002',
    title: 'Wound Assessment Training',
    type: 'video',
    category: 'Training Materials',
    description: 'Video tutorial on proper wound assessment techniques',
    author: 'Dr. Sarah Johnson',
    dateAdded: '2024-02-28',
    tags: ['training', 'assessment', 'video'],
    featured: false
  }
];

const typeColors = {
  document: 'text-blue-500 bg-blue-100 dark:bg-blue-900/30',
  video: 'text-purple-500 bg-purple-100 dark:bg-purple-900/30',
  link: 'text-green-500 bg-green-100 dark:bg-green-900/30',
  guide: 'text-amber-500 bg-amber-100 dark:bg-amber-900/30'
};

const typeIcons = {
  document: FileText,
  video: Video,
  link: LinkIcon,
  guide: Book
};

export default function Resources() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('all');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const filteredResources = MOCK_RESOURCES.filter(resource => {
    const matchesSearch = 
      resource.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      resource.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      resource.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesType = selectedType === 'all' || resource.type === selectedType;
    const matchesCategory = selectedCategory === 'all' || resource.category === selectedCategory;
    return matchesSearch && matchesType && matchesCategory;
  });

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="bg-gradient-to-br from-emerald-600 to-emerald-800 dark:from-gray-800 dark:to-gray-900 rounded-2xl p-8 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2">Resources</h1>
              <p className="text-emerald-100 dark:text-gray-300">
                Access clinical guidelines, training materials, and documentation
              </p>
            </div>
            <div className="p-4 bg-white/10 rounded-xl">
              <BookOpen className="h-8 w-8" />
            </div>
          </div>
        </div>
      </div>

      {/* Quick Access Categories */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        {[
          { name: 'Clinical Guidelines', icon: FileText, count: 12 },
          { name: 'Training Materials', icon: Video, count: 8 },
          { name: 'Documentation', icon: Book, count: 15 },
          { name: 'Quick References', icon: LinkIcon, count: 6 }
        ].map((category) => (
          <div
            key={category.name}
            className="bg-white dark:bg-gray-800 rounded-xl p-4 flex items-center gap-4 hover:shadow-md transition-all duration-200 cursor-pointer"
          >
            <div className="p-3 bg-emerald-100 dark:bg-emerald-900/30 rounded-xl">
              <category.icon className="h-6 w-6 text-emerald-600" />
            </div>
            <div>
              <h3 className="font-medium">{category.name}</h3>
              <p className="text-sm text-gray-500">{category.count} items</p>
            </div>
          </div>
        ))}
      </div>

      {/* Controls */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm mb-6">
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex flex-wrap gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <input
                  type="text"
                  placeholder="Search resources..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700"
                />
              </div>
            </div>
            <div className="flex gap-4">
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700"
              >
                <option value="all">All Types</option>
                <option value="document">Documents</option>
                <option value="video">Videos</option>
                <option value="link">Links</option>
                <option value="guide">Guides</option>
              </select>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700"
              >
                <option value="all">All Categories</option>
                <option value="Clinical Guidelines">Clinical Guidelines</option>
                <option value="Training Materials">Training Materials</option>
                <option value="Documentation">Documentation</option>
              </select>
            </div>
          </div>
        </div>

        <div className="p-4 flex justify-between items-center">
          <div className="flex gap-4">
            <button className="flex items-center gap-2 px-4 py-2 text-emerald-600 border border-emerald-600 rounded-lg hover:bg-emerald-50 dark:hover:bg-emerald-900/20 transition-colors">
              <Folder className="h-5 w-5" />
              My Library
            </button>
          </div>
          <div className="flex gap-2">
            <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
              <Filter className="h-5 w-5" />
            </button>
            <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
              <RefreshCw className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Resources Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredResources.map((resource) => {
          const TypeIcon = typeIcons[resource.type];
          
          return (
            <div
              key={resource.id}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-sm hover:shadow-md transition-all duration-200"
            >
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className={`p-3 rounded-xl ${typeColors[resource.type]}`}>
                    <TypeIcon className="h-6 w-6" />
                  </div>
                  {resource.featured && (
                    <Star className="h-5 w-5 text-amber-500 fill-current" />
                  )}
                </div>

                <h3 className="text-lg font-semibold mb-2">{resource.title}</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                  {resource.description}
                </p>

                <div className="flex flex-wrap gap-2 mb-4">
                  {resource.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-2 py-1 bg-gray-100 dark:bg-gray-700 rounded-full text-xs"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                <div className="flex items-center justify-between text-sm text-gray-500 dark:text-gray-400">
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    {new Date(resource.dateAdded).toLocaleDateString()}
                  </div>
                  {resource.downloadUrl && (
                    <button className="flex items-center gap-2 text-emerald-600 hover:text-emerald-700">
                      <Download className="h-4 w-4" />
                      {resource.fileSize}
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Resource Button */}
      <button
        onClick={() => navigate('/new-resource')}
        className="fixed bottom-20 right-6 bg-emerald-600 text-white p-4 rounded-full shadow-lg hover:bg-emerald-700 transition-colors"
      >
        <Plus className="h-6 w-6" />
      </button>
    </div>
  );
}