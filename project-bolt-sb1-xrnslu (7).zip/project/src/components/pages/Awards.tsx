import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ChevronLeft,
  Award,
  Star,
  Trophy,
  Crown,
  Target,
  Medal,
  Filter,
  Search,
  Download,
  ArrowUpRight,
  Clock,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { useStore } from '../../store/useStore';

const awardIcons = {
  Crown,
  Trophy,
  Star,
  Medal,
  Target,
  Award
};

const MOCK_AWARDS = [
  {
    id: '1',
    title: 'Master Wound Care Specialist',
    description: 'Achieved highest level of wound care certification',
    points: 200,
    category: 'Clinical Excellence',
    status: 'claimed',
    earnedDate: '2024-02-15',
    icon: 'Crown',
    color: 'text-yellow-500',
    requirements: [
      'Complete Advanced Wound Care Certification',
      'Maintain 95% success rate for 6 months',
      'Submit 5 case studies',
      'Pass final assessment'
    ]
  },
  {
    id: '2',
    title: 'Marketing Excellence',
    description: 'Outstanding contribution to wound care product marketing',
    points: 150,
    category: 'Marketing Achievement',
    status: 'in-progress',
    progress: 75,
    icon: 'Star',
    color: 'text-purple-500',
    requirements: [
      'Exceed quarterly sales targets',
      'Launch successful product campaign',
      'Achieve high customer satisfaction',
      'Drive market growth'
    ]
  },
  {
    id: '3',
    title: 'Innovation Champion',
    description: 'Leading innovative marketing strategies in wound care',
    points: 180,
    category: 'Innovation',
    status: 'available',
    icon: 'Trophy',
    color: 'text-blue-500',
    requirements: [
      'Implement new marketing approaches',
      'Drive digital transformation',
      'Lead market research initiatives',
      'Develop creative campaigns'
    ]
  }
];

const statusColors = {
  claimed: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
  available: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
  'in-progress': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300',
  locked: 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300'
};

const statusIcons = {
  claimed: CheckCircle2,
  available: ArrowUpRight,
  'in-progress': Clock,
  locked: AlertCircle
};

export default function Awards() {
  const navigate = useNavigate();
  const { user } = useStore();
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('all');

  const filteredAwards = MOCK_AWARDS.filter(award => {
    const matchesSearch = award.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         award.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || award.category === selectedCategory;
    const matchesStatus = selectedStatus === 'all' || award.status === selectedStatus;
    return matchesSearch && matchesCategory && matchesStatus;
  });

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-8">
        <div className="bg-gradient-to-br from-yellow-600 to-yellow-800 dark:from-gray-800 dark:to-gray-900 rounded-2xl p-8 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2">Awards & Recognition</h1>
              <p className="text-yellow-100 dark:text-gray-300">
                Celebrating excellence in wound care marketing
              </p>
            </div>
            <div className="p-4 bg-white/10 rounded-xl">
              <Trophy className="h-8 w-8" />
            </div>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm mb-6">
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex flex-wrap gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <input
                  type="text"
                  placeholder="Search awards..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700"
                />
              </div>
            </div>
            <div className="flex gap-4">
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700"
              >
                <option value="all">All Categories</option>
                <option value="Marketing Achievement">Marketing Achievement</option>
                <option value="Innovation">Innovation</option>
                <option value="Clinical Excellence">Clinical Excellence</option>
              </select>
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700"
              >
                <option value="all">All Status</option>
                <option value="claimed">Claimed</option>
                <option value="available">Available</option>
                <option value="in-progress">In Progress</option>
                <option value="locked">Locked</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Awards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredAwards.map((award) => {
          const Icon = awardIcons[award.icon as keyof typeof awardIcons];
          const StatusIcon = statusIcons[award.status as keyof typeof statusIcons];
          
          return (
            <div
              key={award.id}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden"
            >
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className={`p-3 rounded-lg ${award.status === 'claimed' ? 'bg-yellow-100 dark:bg-yellow-900/30' : 'bg-gray-100 dark:bg-gray-700'}`}>
                    <Icon className={`h-6 w-6 ${award.color}`} />
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-lg font-bold">{award.points} pts</span>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium flex items-center gap-1 ${
                      statusColors[award.status as keyof typeof statusColors]
                    }`}>
                      <StatusIcon className="h-4 w-4" />
                      {award.status.charAt(0).toUpperCase() + award.status.slice(1)}
                    </span>
                  </div>
                </div>

                <h3 className="text-lg font-semibold mb-2">{award.title}</h3>
                <p className="text-gray-600 dark:text-gray-300 text-sm mb-4">{award.description}</p>

                {award.status === 'in-progress' && award.progress && (
                  <div className="space-y-2 mb-4">
                    <div className="flex justify-between text-sm">
                      <span>Progress</span>
                      <span>{award.progress}%</span>
                    </div>
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                      <div
                        className="bg-blue-600 h-2 rounded-full"
                        style={{ width: `${award.progress}%` }}
                      />
                    </div>
                  </div>
                )}

                <div className="space-y-2">
                  <h4 className="text-sm font-medium">Requirements:</h4>
                  <ul className="space-y-1">
                    {award.requirements.map((req, index) => (
                      <li
                        key={index}
                        className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400"
                      >
                        <div className="w-1.5 h-1.5 rounded-full bg-gray-400" />
                        {req}
                      </li>
                    ))}
                  </ul>
                </div>

                {award.earnedDate && (
                  <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Earned on {new Date(award.earnedDate).toLocaleDateString()}
                    </p>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}