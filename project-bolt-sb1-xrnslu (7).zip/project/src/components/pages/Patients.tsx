import React, { useState } from 'react';
import {
  Search,
  Filter,
  Plus,
  Download,
  RefreshCw,
  Users,
  Clock,
  Calendar,
  FileText,
  MoreVertical,
  Activity,
  AlertCircle,
  Heart
} from 'lucide-react';

interface Patient {
  id: string;
  name: string;
  age: number;
  gender: string;
  condition: string;
  status: 'stable' | 'critical' | 'improving' | 'deteriorating';
  lastVisit: string;
  nextAppointment: string;
  assignedDoctor: string;
  vitalSigns: {
    bloodPressure: string;
    heartRate: number;
    temperature: number;
  };
}

const MOCK_PATIENTS: Patient[] = [
  {
    id: 'P001',
    name: 'John Smith',
    age: 45,
    gender: 'Male',
    condition: 'Diabetic Foot Ulcer',
    status: 'improving',
    lastVisit: '2024-03-10',
    nextAppointment: '2024-03-17',
    assignedDoctor: 'Peter Schuck',
    vitalSigns: {
      bloodPressure: '120/80',
      heartRate: 72,
      temperature: 98.6
    }
  },
  {
    id: 'P002',
    name: 'Sarah Wilson',
    age: 62,
    gender: 'Female',
    condition: 'Venous Leg Ulcer',
    status: 'stable',
    lastVisit: '2024-03-12',
    nextAppointment: '2024-03-19',
    assignedDoctor: 'Peter Schuck',
    vitalSigns: {
      bloodPressure: '130/85',
      heartRate: 75,
      temperature: 98.4
    }
  }
];

const statusColors = {
  stable: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
  critical: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
  improving: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
  deteriorating: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300'
};

export default function Patients() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [view, setView] = useState<'list' | 'grid'>('list');

  const filteredPatients = MOCK_PATIENTS.filter(patient => {
    const matchesSearch = 
      patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patient.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = selectedStatus === 'all' || patient.status === selectedStatus;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="bg-gradient-to-br from-indigo-600 to-indigo-800 dark:from-gray-800 dark:to-gray-900 rounded-2xl p-8 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2">Patient Management</h1>
              <p className="text-indigo-100 dark:text-gray-300">
                View and manage patient records
              </p>
            </div>
            <div className="p-4 bg-white/10 rounded-xl">
              <Users className="h-8 w-8" />
            </div>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm mb-6">
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex flex-wrap gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <input
                  type="text"
                  placeholder="Search patients..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700"
                />
              </div>
            </div>
            <div className="flex gap-4">
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700"
              >
                <option value="all">All Status</option>
                <option value="stable">Stable</option>
                <option value="critical">Critical</option>
                <option value="improving">Improving</option>
                <option value="deteriorating">Deteriorating</option>
              </select>
            </div>
          </div>
        </div>

        <div className="p-4 flex justify-between items-center">
          <div className="flex gap-4">
            <button
              onClick={() => setView('list')}
              className={`px-4 py-2 rounded-lg ${
                view === 'list'
                  ? 'bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600'
                  : 'hover:bg-gray-100 dark:hover:bg-gray-700'
              }`}
            >
              List View
            </button>
            <button
              onClick={() => setView('grid')}
              className={`px-4 py-2 rounded-lg ${
                view === 'grid'
                  ? 'bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600'
                  : 'hover:bg-gray-100 dark:hover:bg-gray-700'
              }`}
            >
              Grid View
            </button>
          </div>
          <div className="flex gap-2">
            <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
              <Filter className="h-5 w-5" />
            </button>
            <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
              <Download className="h-5 w-5" />
            </button>
            <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
              <RefreshCw className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Patient List */}
      <div className="space-y-4">
        {filteredPatients.map((patient) => (
          <div
            key={patient.id}
            className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 hover:shadow-md transition-all duration-200"
          >
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <h3 className="text-lg font-semibold">{patient.name}</h3>
                  <span className="text-sm text-gray-500">({patient.id})</span>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    statusColors[patient.status]
                  }`}>
                    {patient.status.charAt(0).toUpperCase() + patient.status.slice(1)}
                  </span>
                </div>
                <p className="text-gray-600 dark:text-gray-300 mb-4">{patient.condition}</p>
              </div>
              <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
                <MoreVertical className="h-5 w-5" />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
              <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                <Clock className="h-4 w-4" />
                Last Visit: {new Date(patient.lastVisit).toLocaleDateString()}
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                <Calendar className="h-4 w-4" />
                Next Appointment: {new Date(patient.nextAppointment).toLocaleDateString()}
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                <Users className="h-4 w-4" />
                {patient.assignedDoctor}
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                <FileText className="h-4 w-4" />
                View Records
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
              <div className="flex items-center gap-3">
                <Activity className="h-5 w-5 text-blue-500" />
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Blood Pressure</p>
                  <p className="font-semibold">{patient.vitalSigns.bloodPressure}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Heart className="h-5 w-5 text-red-500" />
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Heart Rate</p>
                  <p className="font-semibold">{patient.vitalSigns.heartRate} BPM</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <AlertCircle className="h-5 w-5 text-yellow-500" />
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Temperature</p>
                  <p className="font-semibold">{patient.vitalSigns.temperature}°F</p>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add Patient Button */}
      <button
        className="fixed bottom-20 right-6 bg-indigo-600 text-white p-4 rounded-full shadow-lg hover:bg-indigo-700 transition-colors"
      >
        <Plus className="h-6 w-6" />
      </button>
    </div>
  );
}