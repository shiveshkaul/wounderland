import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Search,
  Filter,
  Plus,
  Calendar,
  Clock,
  Users,
  FileText,
  MoreVertical,
  AlertCircle,
  CheckCircle2,
  Timer,
  ArrowUpRight,
  Download,
  RefreshCw,
  Stethoscope
} from 'lucide-react';

interface Case {
  id: string;
  patientName: string;
  patientId: string;
  condition: string;
  status: 'active' | 'monitoring' | 'resolved' | 'critical';
  priority: 'high' | 'medium' | 'low';
  assignedTo: string;
  lastUpdated: string;
  nextReview: string;
  progress: number;
  tags: string[];
  notes: string;
}

const MOCK_CASES: Case[] = [
  {
    id: 'WC-2024-001',
    patientName: 'John Smith',
    patientId: 'P-10234',
    condition: 'Diabetic Foot Ulcer',
    status: 'active',
    priority: 'high',
    assignedTo: 'Peter Schuck',
    lastUpdated: '2024-03-14T10:30:00',
    nextReview: '2024-03-16T14:00:00',
    progress: 65,
    tags: ['diabetes', 'ulcer', 'critical-care'],
    notes: 'Patient showing positive response to new treatment protocol.'
  },
  {
    id: 'WC-2024-002',
    patientName: 'Sarah Wilson',
    patientId: 'P-10235',
    condition: 'Pressure Injury',
    status: 'monitoring',
    priority: 'medium',
    assignedTo: 'Peter Schuck',
    lastUpdated: '2024-03-14T09:15:00',
    nextReview: '2024-03-17T11:30:00',
    progress: 85,
    tags: ['pressure-injury', 'stage-2'],
    notes: 'Wound showing significant improvement with current treatment plan.'
  }
];

const statusColors = {
  active: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
  monitoring: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300',
  resolved: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
  critical: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300'
};

const priorityColors = {
  high: 'text-red-500',
  medium: 'text-yellow-500',
  low: 'text-green-500'
};

const statusIcons = {
  active: ArrowUpRight,
  monitoring: Timer,
  resolved: CheckCircle2,
  critical: AlertCircle
};

export default function Cases() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedPriority, setSelectedPriority] = useState('all');
  const [view, setView] = useState<'list' | 'grid'>('list');

  const filteredCases = MOCK_CASES.filter(caseItem => {
    const matchesSearch = 
      caseItem.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      caseItem.patientId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      caseItem.condition.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = selectedStatus === 'all' || caseItem.status === selectedStatus;
    const matchesPriority = selectedPriority === 'all' || caseItem.priority === selectedPriority;
    return matchesSearch && matchesStatus && matchesPriority;
  });

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="bg-gradient-to-br from-blue-600 to-blue-800 dark:from-gray-800 dark:to-gray-900 rounded-2xl p-8 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2">Case Management</h1>
              <p className="text-blue-100 dark:text-gray-300">
                Track and manage patient cases efficiently
              </p>
            </div>
            <div className="p-4 bg-white/10 rounded-xl">
              <Stethoscope className="h-8 w-8" />
            </div>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm mb-6">
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex flex-wrap gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <input
                  type="text"
                  placeholder="Search cases by patient name, ID, or condition..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700"
                />
              </div>
            </div>
            <div className="flex gap-4">
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700"
              >
                <option value="all">All Status</option>
                <option value="active">Active</option>
                <option value="monitoring">Monitoring</option>
                <option value="resolved">Resolved</option>
                <option value="critical">Critical</option>
              </select>
              <select
                value={selectedPriority}
                onChange={(e) => setSelectedPriority(e.target.value)}
                className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700"
              >
                <option value="all">All Priorities</option>
                <option value="high">High Priority</option>
                <option value="medium">Medium Priority</option>
                <option value="low">Low Priority</option>
              </select>
            </div>
          </div>
        </div>

        <div className="p-4 flex justify-between items-center">
          <div className="flex gap-4">
            <button
              onClick={() => setView('list')}
              className={`px-4 py-2 rounded-lg ${
                view === 'list'
                  ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-600'
                  : 'hover:bg-gray-100 dark:hover:bg-gray-700'
              }`}
            >
              List View
            </button>
            <button
              onClick={() => setView('grid')}
              className={`px-4 py-2 rounded-lg ${
                view === 'grid'
                  ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-600'
                  : 'hover:bg-gray-100 dark:hover:bg-gray-700'
              }`}
            >
              Grid View
            </button>
          </div>
          <div className="flex gap-2">
            <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
              <Filter className="h-5 w-5" />
            </button>
            <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
              <Download className="h-5 w-5" />
            </button>
            <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
              <RefreshCw className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Cases List */}
      <div className="space-y-4">
        {filteredCases.map((caseItem) => {
          const StatusIcon = statusIcons[caseItem.status];
          
          return (
            <div
              key={caseItem.id}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 hover:shadow-md transition-all duration-200"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-semibold">{caseItem.patientName}</h3>
                    <span className="text-sm text-gray-500">({caseItem.patientId})</span>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium flex items-center gap-1 ${
                      statusColors[caseItem.status]
                    }`}>
                      <StatusIcon className="h-4 w-4" />
                      {caseItem.status.charAt(0).toUpperCase() + caseItem.status.slice(1)}
                    </span>
                    <AlertCircle className={`h-5 w-5 ${priorityColors[caseItem.priority]}`} />
                  </div>
                  <p className="text-gray-600 dark:text-gray-300 mb-4">{caseItem.condition}</p>
                </div>
                <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
                  <MoreVertical className="h-5 w-5" />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                  <Users className="h-4 w-4" />
                  {caseItem.assignedTo}
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                  <Clock className="h-4 w-4" />
                  Last updated: {new Date(caseItem.lastUpdated).toLocaleString()}
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                  <Calendar className="h-4 w-4" />
                  Next review: {new Date(caseItem.nextReview).toLocaleString()}
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                  <FileText className="h-4 w-4" />
                  Progress Notes
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between items-center text-sm">
                  <span className="text-gray-600 dark:text-gray-400">Treatment Progress</span>
                  <span className="font-medium">{caseItem.progress}%</span>
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                  <div
                    className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${caseItem.progress}%` }}
                  />
                </div>
              </div>

              <div className="flex flex-wrap gap-2 mt-4">
                {caseItem.tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-2 py-1 bg-gray-100 dark:bg-gray-700 rounded-full text-xs"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Case Button */}
      <button
        onClick={() => navigate('/new-case')}
        className="fixed bottom-20 right-6 bg-blue-600 text-white p-4 rounded-full shadow-lg hover:bg-blue-700 transition-colors"
      >
        <Plus className="h-6 w-6" />
      </button>
    </div>
  );
}