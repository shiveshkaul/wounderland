import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ChevronLeft,
  Video,
  Phone,
  Calendar,
  Clock,
  Users,
  MessageSquare,
  Plus,
  Search,
  Filter,
  RefreshCw,
  AlertCircle,
  CheckCircle2,
  Timer
} from 'lucide-react';

interface Consultation {
  id: string;
  patientName: string;
  patientId: string;
  type: 'video' | 'phone';
  status: 'scheduled' | 'in-progress' | 'completed' | 'cancelled';
  dateTime: string;
  duration: string;
  provider: string;
  reason: string;
  notes?: string;
}

const MOCK_CONSULTATIONS: Consultation[] = [
  {
    id: 'CONS-001',
    patientName: 'John Smith',
    patientId: 'P-10234',
    type: 'video',
    status: 'scheduled',
    dateTime: '2024-03-15T14:30:00',
    duration: '30m',
    provider: 'Peter Schuck',
    reason: 'Follow-up wound assessment',
    notes: 'Patient reported improved healing'
  },
  {
    id: 'CONS-002',
    patientName: 'Sarah Wilson',
    patientId: 'P-10235',
    type: 'phone',
    status: 'completed',
    dateTime: '2024-03-14T10:00:00',
    duration: '15m',
    provider: 'Peter Schuck',
    reason: 'Treatment plan discussion'
  }
];

const statusColors = {
  scheduled: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
  'in-progress': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300',
  completed: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
  cancelled: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300'
};

const statusIcons = {
  scheduled: Timer,
  'in-progress': AlertCircle,
  completed: CheckCircle2,
  cancelled: AlertCircle
};

export default function Consult() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedType, setSelectedType] = useState('all');

  const filteredConsultations = MOCK_CONSULTATIONS.filter(consultation => {
    const matchesSearch = 
      consultation.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      consultation.patientId.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = selectedStatus === 'all' || consultation.status === selectedStatus;
    const matchesType = selectedType === 'all' || consultation.type === selectedType;
    return matchesSearch && matchesStatus && matchesType;
  });

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="bg-gradient-to-br from-purple-600 to-purple-800 dark:from-gray-800 dark:to-gray-900 rounded-2xl p-8 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2">Consultations</h1>
              <p className="text-purple-100 dark:text-gray-300">
                Manage virtual consultations and follow-ups
              </p>
            </div>
            <div className="p-4 bg-white/10 rounded-xl">
              <Video className="h-8 w-8" />
            </div>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm mb-6">
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex flex-wrap gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <input
                  type="text"
                  placeholder="Search consultations..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700"
                />
              </div>
            </div>
            <div className="flex gap-4">
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700"
              >
                <option value="all">All Status</option>
                <option value="scheduled">Scheduled</option>
                <option value="in-progress">In Progress</option>
                <option value="completed">Completed</option>
                <option value="cancelled">Cancelled</option>
              </select>
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700"
              >
                <option value="all">All Types</option>
                <option value="video">Video Call</option>
                <option value="phone">Phone Call</option>
              </select>
            </div>
          </div>
        </div>

        <div className="p-4 flex justify-between items-center">
          <div className="flex gap-2">
            <button className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
              Join Next Call
            </button>
          </div>
          <div className="flex gap-2">
            <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
              <Filter className="h-5 w-5" />
            </button>
            <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
              <RefreshCw className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Consultations List */}
      <div className="space-y-4">
        {filteredConsultations.map((consultation) => {
          const StatusIcon = statusIcons[consultation.status];
          
          return (
            <div
              key={consultation.id}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 hover:shadow-md transition-all duration-200"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-semibold">{consultation.patientName}</h3>
                    <span className="text-sm text-gray-500">({consultation.patientId})</span>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium flex items-center gap-1 ${
                      statusColors[consultation.status]
                    }`}>
                      <StatusIcon className="h-4 w-4" />
                      {consultation.status.charAt(0).toUpperCase() + consultation.status.slice(1)}
                    </span>
                    {consultation.type === 'video' ? (
                      <Video className="h-5 w-5 text-purple-500" />
                    ) : (
                      <Phone className="h-5 w-5 text-blue-500" />
                    )}
                  </div>
                  <p className="text-gray-600 dark:text-gray-300 mb-4">{consultation.reason}</p>
                </div>
                <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
                  <MessageSquare className="h-5 w-5" />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                  <Calendar className="h-4 w-4" />
                  {new Date(consultation.dateTime).toLocaleDateString()}
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                  <Clock className="h-4 w-4" />
                  {new Date(consultation.dateTime).toLocaleTimeString()} ({consultation.duration})
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                  <Users className="h-4 w-4" />
                  {consultation.provider}
                </div>
              </div>

              {consultation.notes && (
                <p className="mt-4 text-sm text-gray-500 dark:text-gray-400 bg-gray-50 dark:bg-gray-700/50 p-3 rounded-lg">
                  {consultation.notes}
                </p>
              )}
            </div>
          );
        })}
      </div>

      {/* Add Consultation Button */}
      <button
        onClick={() => navigate('/new-consultation')}
        className="fixed bottom-20 right-6 bg-purple-600 text-white p-4 rounded-full shadow-lg hover:bg-purple-700 transition-colors"
      >
        <Plus className="h-6 w-6" />
      </button>
    </div>
  );
}