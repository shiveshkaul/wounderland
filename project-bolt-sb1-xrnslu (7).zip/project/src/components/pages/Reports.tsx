import React, { useState } from 'react';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';
import {
  Download,
  Filter,
  RefreshCw,
  Calendar,
  TrendingUp,
  Users,
  Activity,
  FileText,
  Printer,
  Share2
} from 'lucide-react';

const performanceData = [
  { month: 'Jan', cases: 45, success: 40, referrals: 20 },
  { month: 'Feb', cases: 52, success: 45, referrals: 25 },
  { month: 'Mar', cases: 48, success: 42, referrals: 22 },
  { month: 'Apr', cases: 61, success: 55, referrals: 30 },
  { month: 'May', cases: 55, success: 48, referrals: 28 },
  { month: 'Jun', cases: 67, success: 60, referrals: 35 }
];

const patientData = [
  { age: '0-20', count: 15 },
  { age: '21-40', count: 30 },
  { age: '41-60', count: 45 },
  { age: '61-80', count: 35 },
  { age: '80+', count: 20 }
];

export default function Reports() {
  const [timeframe, setTimeframe] = useState('6M');
  const [reportType, setReportType] = useState('all');

  const kpis = [
    { title: 'Total Cases', value: '328', change: '+15.3%', icon: FileText, trend: 'up' },
    { title: 'Success Rate', value: '92%', change: '+5.2%', icon: TrendingUp, trend: 'up' },
    { title: 'Active Patients', value: '245', change: '+8.1%', icon: Users, trend: 'up' },
    { title: 'Referrals', value: '64', change: '+12.5%', icon: Activity, trend: 'up' }
  ];

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="bg-gradient-to-br from-purple-600 to-purple-800 dark:from-gray-800 dark:to-gray-900 rounded-2xl p-8 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2">Reports & Analytics</h1>
              <p className="text-purple-100 dark:text-gray-300">
                Comprehensive insights and performance metrics
              </p>
            </div>
            <div className="p-4 bg-white/10 rounded-xl">
              <Activity className="h-8 w-8" />
            </div>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm mb-6">
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex flex-wrap gap-4">
            <div className="flex items-center gap-2 bg-white dark:bg-gray-800 rounded-lg p-2">
              <button
                className={`px-4 py-2 rounded-md ${
                  timeframe === '1M' ? 'bg-purple-100 dark:bg-purple-900/30 text-purple-600' : ''
                }`}
                onClick={() => setTimeframe('1M')}
              >
                1M
              </button>
              <button
                className={`px-4 py-2 rounded-md ${
                  timeframe === '6M' ? 'bg-purple-100 dark:bg-purple-900/30 text-purple-600' : ''
                }`}
                onClick={() => setTimeframe('6M')}
              >
                6M
              </button>
              <button
                className={`px-4 py-2 rounded-md ${
                  timeframe === '1Y' ? 'bg-purple-100 dark:bg-purple-900/30 text-purple-600' : ''
                }`}
                onClick={() => setTimeframe('1Y')}
              >
                1Y
              </button>
              <button
                className={`px-4 py-2 rounded-md ${
                  timeframe === 'ALL' ? 'bg-purple-100 dark:bg-purple-900/30 text-purple-600' : ''
                }`}
                onClick={() => setTimeframe('ALL')}
              >
                ALL
              </button>
            </div>
            <div className="flex gap-2 ml-auto">
              <button className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-gray-800 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700">
                <Calendar className="h-5 w-5" />
                Custom Range
              </button>
              <button className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-gray-800 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700">
                <Filter className="h-5 w-5" />
                Filters
              </button>
              <button className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-gray-800 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700">
                <Download className="h-5 w-5" />
                Export
              </button>
              <button className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-gray-800 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700">
                <RefreshCw className="h-5 w-5" />
                Refresh
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        {kpis.map((kpi, index) => (
          <div key={index} className="bg-white dark:bg-gray-800 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-purple-100 dark:bg-purple-900/30 rounded-xl">
                <kpi.icon className="h-6 w-6 text-purple-600" />
              </div>
              <span className={`text-sm ${kpi.trend === 'up' ? 'text-green-600' : 'text-red-600'}`}>
                {kpi.change}
              </span>
            </div>
            <h3 className="text-gray-600 dark:text-gray-400 text-sm font-medium mb-2">{kpi.title}</h3>
            <p className="text-2xl font-bold">{kpi.value}</p>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl p-6">
          <h3 className="text-lg font-semibold mb-6">Performance Trends</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="cases" stroke="#8b5cf6" name="Total Cases" />
                <Line type="monotone" dataKey="success" stroke="#10b981" name="Successful Cases" />
                <Line type="monotone" dataKey="referrals" stroke="#3b82f6" name="Referrals" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl p-6">
          <h3 className="text-lg font-semibold mb-6">Patient Age Distribution</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={patientData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="age" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="count" fill="#8b5cf6" name="Patients" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Report Actions */}
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold">Available Reports</h3>
          <div className="flex gap-2">
            <button className="flex items-center gap-2 px-4 py-2 text-purple-600 border border-purple-600 rounded-lg hover:bg-purple-50 dark:hover:bg-purple-900/20">
              <Printer className="h-5 w-5" />
              Print Report
            </button>
            <button className="flex items-center gap-2 px-4 py-2 text-purple-600 border border-purple-600 rounded-lg hover:bg-purple-50 dark:hover:bg-purple-900/20">
              <Share2 className="h-5 w-5" />
              Share Report
            </button>
          </div>
        </div>

        <div className="space-y-4">
          {[
            'Monthly Performance Summary',
            'Patient Demographics Analysis',
            'Treatment Success Metrics',
            'Resource Utilization Report'
          ].map((report, index) => (
            <div
              key={index}
              className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
            >
              <div className="flex items-center gap-3">
                <FileText className="h-5 w-5 text-purple-600" />
                <span className="font-medium">{report}</span>
              </div>
              <button className="text-purple-600 hover:text-purple-700">
                <Download className="h-5 w-5" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}