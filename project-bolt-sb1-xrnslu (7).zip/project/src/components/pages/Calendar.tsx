import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Filter } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface Event {
  id: string;
  title: string;
  date: string;
  time: string;
  type: string;
  status: 'scheduled' | 'completed' | 'cancelled';
}

const MOCK_EVENTS: Event[] = [
  {
    id: '1',
    title: 'Patient Consultation',
    date: '2024-03-15',
    time: '09:00',
    type: 'Consultation',
    status: 'scheduled'
  },
  {
    id: '2',
    title: 'Team Meeting',
    date: '2024-03-15',
    time: '14:00',
    type: 'Meeting',
    status: 'scheduled'
  }
];

export default function Calendar() {
  const navigate = useNavigate();
  const [view, setView] = useState<'day' | 'week' | 'month'>('day');
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(new Date());

  const handlePrevious = () => {
    const newDate = new Date(currentDate);
    switch (view) {
      case 'day':
        newDate.setDate(currentDate.getDate() - 1);
        break;
      case 'week':
        newDate.setDate(currentDate.getDate() - 7);
        break;
      case 'month':
        newDate.setMonth(currentDate.getMonth() - 1);
        break;
    }
    setCurrentDate(newDate);
  };

  const handleNext = () => {
    const newDate = new Date(currentDate);
    switch (view) {
      case 'day':
        newDate.setDate(currentDate.getDate() + 1);
        break;
      case 'week':
        newDate.setDate(currentDate.getDate() + 7);
        break;
      case 'month':
        newDate.setMonth(currentDate.getMonth() + 1);
        break;
    }
    setCurrentDate(newDate);
  };

  const handleToday = () => {
    setCurrentDate(new Date());
    setSelectedDate(new Date());
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex items-center gap-4 mb-8">
        <button
          onClick={() => navigate('/')}
          className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        <h1 className="text-2xl font-bold">Calendar</h1>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm">
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <button
                  onClick={handlePrevious}
                  className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
                >
                  <ChevronLeft className="h-5 w-5" />
                </button>
                <button
                  onClick={handleNext}
                  className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
                >
                  <ChevronRight className="h-5 w-5" />
                </button>
                <h2 className="text-lg font-semibold">
                  {currentDate.toLocaleString('default', { 
                    month: 'long',
                    year: 'numeric'
                  })}
                </h2>
              </div>
              <button
                onClick={handleToday}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Today
              </button>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex bg-gray-100 dark:bg-gray-700 rounded-lg p-1">
                <button
                  onClick={() => setView('day')}
                  className={`px-4 py-2 rounded-lg ${
                    view === 'day'
                      ? 'bg-white dark:bg-gray-600 shadow'
                      : 'hover:bg-white/50 dark:hover:bg-gray-600/50'
                  }`}
                >
                  Day
                </button>
                <button
                  onClick={() => setView('week')}
                  className={`px-4 py-2 rounded-lg ${
                    view === 'week'
                      ? 'bg-white dark:bg-gray-600 shadow'
                      : 'hover:bg-white/50 dark:hover:bg-gray-600/50'
                  }`}
                >
                  Week
                </button>
                <button
                  onClick={() => setView('month')}
                  className={`px-4 py-2 rounded-lg ${
                    view === 'month'
                      ? 'bg-white dark:bg-gray-600 shadow'
                      : 'hover:bg-white/50 dark:hover:bg-gray-600/50'
                  }`}
                >
                  Month
                </button>
              </div>
              <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
                <Filter className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>

        <div className="p-4">
          {/* Calendar Grid */}
          <div className="grid grid-cols-7 gap-px bg-gray-200 dark:bg-gray-700 rounded-lg overflow-hidden">
            {/* Header */}
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
              <div
                key={day}
                className="bg-gray-50 dark:bg-gray-800 p-4 text-center font-medium"
              >
                {day}
              </div>
            ))}
            
            {/* Calendar Days */}
            {Array.from({ length: 35 }, (_, i) => {
              const date = new Date(currentDate.getFullYear(), currentDate.getMonth(), i - currentDate.getDay() + 1);
              const isCurrentMonth = date.getMonth() === currentDate.getMonth();
              const isToday = date.toDateString() === new Date().toDateString();
              const isSelected = date.toDateString() === selectedDate.toDateString();
              
              return (
                <button
                  key={i}
                  onClick={() => setSelectedDate(date)}
                  className={`min-h-[120px] p-4 text-left transition-colors ${
                    isCurrentMonth
                      ? 'bg-white dark:bg-gray-800'
                      : 'bg-gray-50 dark:bg-gray-700/50 text-gray-400 dark:text-gray-500'
                  } ${
                    isToday
                      ? 'ring-2 ring-blue-500 ring-inset'
                      : ''
                  } ${
                    isSelected
                      ? 'bg-blue-50 dark:bg-blue-900/20'
                      : ''
                  }`}
                >
                  <span className={`inline-flex items-center justify-center w-8 h-8 rounded-full ${
                    isToday
                      ? 'bg-blue-600 text-white'
                      : ''
                  }`}>
                    {date.getDate()}
                  </span>
                  
                  {/* Events */}
                  <div className="mt-2 space-y-1">
                    {MOCK_EVENTS
                      .filter(event => event.date === date.toISOString().split('T')[0])
                      .map(event => (
                        <div
                          key={event.id}
                          className="px-2 py-1 text-xs rounded bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-200"
                        >
                          {event.time} - {event.title}
                        </div>
                      ))
                    }
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}