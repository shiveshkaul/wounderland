import React from 'react';
import {
  Mail,
  Search,
  Filter,
  Download,
  RefreshCw,
  Plus,
  Send,
  Users,
  BarChart2,
  Clock
} from 'lucide-react';

export default function Communications() {
  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="bg-gradient-to-br from-violet-600 to-violet-800 dark:from-gray-800 dark:to-gray-900 rounded-2xl p-8 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2">Communications</h1>
              <p className="text-violet-100 dark:text-gray-300">
                Email and newsletter campaigns
              </p>
            </div>
            <div className="p-4 bg-white/10 rounded-xl">
              <Mail className="h-8 w-8" />
            </div>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm mb-6">
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex flex-wrap gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <input
                  type="text"
                  placeholder="Search campaigns..."
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <button className="flex items-center gap-2 px-4 py-2 bg-violet-600 text-white rounded-lg hover:bg-violet-700">
                <Plus className="h-5 w-5" />
                New Campaign
              </button>
              <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
                <Filter className="h-5 w-5" />
              </button>
              <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
                <Download className="h-5 w-5" />
              </button>
              <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
                <RefreshCw className="h-5 w-5" />
              </button>
              <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
                <BarChart2 className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Campaign Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-violet-100 dark:bg-violet-900/30 rounded-lg">
              <Send className="h-6 w-6 text-violet-600" />
            </div>
            <span className="text-sm text-green-600">+12.5%</span>
          </div>
          <h3 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-2">Sent Emails</h3>
          <p className="text-2xl font-bold">24.5K</p>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-violet-100 dark:bg-violet-900/30 rounded-lg">
              <Users className="h-6 w-6 text-violet-600" />
            </div>
            <span className="text-sm text-green-600">+8.3%</span>
          </div>
          <h3 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-2">Subscribers</h3>
          <p className="text-2xl font-bold">12.8K</p>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-violet-100 dark:bg-violet-900/30 rounded-lg">
              <BarChart2 className="h-6 w-6 text-violet-600" />
            </div>
            <span className="text-sm text-green-600">+15.7%</span>
          </div>
          <h3 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-2">Open Rate</h3>
          <p className="text-2xl font-bold">32.4%</p>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-violet-100 dark:bg-violet-900/30 rounded-lg">
              <Clock className="h-6 w-6 text-violet-600" />
            </div>
            <span className="text-sm text-green-600">+10.2%</span>
          </div>
          <h3 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-2">Click Rate</h3>
          <p className="text-2xl font-bold">18.5%</p>
        </div>
      </div>

      {/* Recent Campaigns */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6">
        <h2 className="text-lg font-semibold mb-6">Recent Campaigns</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200 dark:border-gray-700">
                <th className="text-left py-4 px-4">Campaign Name</th>
                <th className="text-left py-4 px-4">Status</th>
                <th className="text-right py-4 px-4">Recipients</th>
                <th className="text-right py-4 px-4">Open Rate</th>
                <th className="text-right py-4 px-4">Click Rate</th>
                <th className="text-right py-4 px-4">Sent Date</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-gray-200 dark:border-gray-700">
                <td className="py-4 px-4">Q1 Product Newsletter</td>
                <td className="py-4 px-4">
                  <span className="px-2 py-1 bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300 rounded-full text-xs">
                    Sent
                  </span>
                </td>
                <td className="text-right py-4 px-4">5,234</td>
                <td className="text-right py-4 px-4">34.2%</td>
                <td className="text-right py-4 px-4">12.8%</td>
                <td className="text-right py-4 px-4">Mar 15, 2024</td>
              </tr>
              <tr className="border-b border-gray-200 dark:border-gray-700">
                <td className="py-4 px-4">New Product Launch</td>
                <td className="py-4 px-4">
                  <span className="px-2 py-1 bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300 rounded-full text-xs">
                    Draft
                  </span>
                </td>
                <td className="text-right py-4 px-4">-</td>
                <td className="text-right py-4 px-4">-</td>
                <td className="text-right py-4 px-4">-</td>
                <td className="text-right py-4 px-4">-</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}