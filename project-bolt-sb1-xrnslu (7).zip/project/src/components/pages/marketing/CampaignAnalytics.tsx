import React from 'react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';
import {
  TrendingUp,
  Users,
  Target,
  ArrowUp,
  ArrowDown,
  Filter,
  Download,
  Calendar,
  RefreshCw
} from 'lucide-react';

const campaignData = [
  { month: 'Jan', reach: 45000, engagement: 12000, conversions: 2800 },
  { month: 'Feb', reach: 52000, engagement: 15000, conversions: 3200 },
  { month: 'Mar', reach: 48000, engagement: 13500, conversions: 3000 },
  { month: 'Apr', reach: 61000, engagement: 18000, conversions: 4100 },
  { month: 'May', reach: 55000, engagement: 16500, conversions: 3800 },
  { month: 'Jun', reach: 67000, engagement: 20000, conversions: 4500 }
];

interface MetricCardProps {
  title: string;
  value: string;
  change: string;
  icon: React.ElementType;
  trend: 'up' | 'down';
}

const MetricCard: React.FC<MetricCardProps> = ({ title, value, change, icon: Icon, trend }) => (
  <div className="bg-white dark:bg-gray-800 rounded-lg p-6">
    <div className="flex items-center justify-between mb-4">
      <div className="p-3 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
        <Icon className="h-6 w-6 text-blue-600" />
      </div>
      <span className={`flex items-center text-sm ${
        trend === 'up' ? 'text-green-600' : 'text-red-600'
      }`}>
        {trend === 'up' ? <ArrowUp className="h-4 w-4 mr-1" /> : <ArrowDown className="h-4 w-4 mr-1" />}
        {change}
      </span>
    </div>
    <h3 className="text-gray-600 dark:text-gray-400 text-sm font-medium mb-2">{title}</h3>
    <p className="text-2xl font-bold">{value}</p>
  </div>
);

export default function CampaignAnalytics() {
  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="bg-gradient-to-br from-blue-600 to-blue-800 dark:from-gray-800 dark:to-gray-900 rounded-2xl p-8 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2">Campaign Analytics</h1>
              <p className="text-blue-100 dark:text-gray-300">
                Track and optimize your marketing campaigns
              </p>
            </div>
            <div className="p-4 bg-white/10 rounded-xl">
              <TrendingUp className="h-8 w-8" />
            </div>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="flex justify-between items-center mb-6">
        <div className="flex gap-4">
          <select className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700">
            <option>Last 30 Days</option>
            <option>Last 90 Days</option>
            <option>Last 6 Months</option>
            <option>Last Year</option>
          </select>
          <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700">
            <Calendar className="h-5 w-5" />
            Custom Range
          </button>
        </div>
        <div className="flex gap-2">
          <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
            <Filter className="h-5 w-5" />
          </button>
          <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
            <Download className="h-5 w-5" />
          </button>
          <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
            <RefreshCw className="h-5 w-5" />
          </button>
        </div>
      </div>

      {/* Metrics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <MetricCard
          title="Total Reach"
          value="328.5K"
          change="+15.3%"
          icon={Users}
          trend="up"
        />
        <MetricCard
          title="Engagement Rate"
          value="32.8%"
          change="+8.7%"
          icon={Target}
          trend="up"
        />
        <MetricCard
          title="Conversions"
          value="4,521"
          change="+12.4%"
          icon={TrendingUp}
          trend="up"
        />
        <MetricCard
          title="ROI"
          value="285%"
          change="-2.3%"
          icon={TrendingUp}
          trend="down"
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6">
          <h3 className="text-lg font-semibold mb-6">Campaign Performance</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={campaignData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="reach" stroke="#3B82F6" name="Reach" />
                <Line type="monotone" dataKey="engagement" stroke="#10B981" name="Engagement" />
                <Line type="monotone" dataKey="conversions" stroke="#6366F1" name="Conversions" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg p-6">
          <h3 className="text-lg font-semibold mb-6">Channel Performance</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={campaignData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="engagement" fill="#3B82F6" name="Engagement" />
                <Bar dataKey="conversions" fill="#10B981" name="Conversions" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}