import React from 'react';
import {
  Globe,
  Search,
  Filter,
  Download,
  RefreshCw,
  BarChart2,
  Share2,
  MessageSquare,
  ThumbsUp,
  Eye,
  TrendingUp
} from 'lucide-react';

export default function DigitalPresence() {
  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="bg-gradient-to-br from-cyan-600 to-cyan-800 dark:from-gray-800 dark:to-gray-900 rounded-2xl p-8 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2">Digital Presence</h1>
              <p className="text-cyan-100 dark:text-gray-300">
                Website and social media analytics
              </p>
            </div>
            <div className="p-4 bg-white/10 rounded-xl">
              <Globe className="h-8 w-8" />
            </div>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm mb-6">
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex flex-wrap gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <input
                  type="text"
                  placeholder="Search analytics..."
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
                <Filter className="h-5 w-5" />
              </button>
              <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
                <Download className="h-5 w-5" />
              </button>
              <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
                <RefreshCw className="h-5 w-5" />
              </button>
              <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
                <BarChart2 className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Analytics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-cyan-100 dark:bg-cyan-900/30 rounded-lg">
              <Eye className="h-6 w-6 text-cyan-600" />
            </div>
            <span className="text-sm text-green-600">+12.5%</span>
          </div>
          <h3 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-2">Website Visits</h3>
          <p className="text-2xl font-bold">24.5K</p>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-cyan-100 dark:bg-cyan-900/30 rounded-lg">
              <Share2 className="h-6 w-6 text-cyan-600" />
            </div>
            <span className="text-sm text-green-600">+8.3%</span>
          </div>
          <h3 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-2">Social Shares</h3>
          <p className="text-2xl font-bold">1.2K</p>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-cyan-100 dark:bg-cyan-900/30 rounded-lg">
              <MessageSquare className="h-6 w-6 text-cyan-600" />
            </div>
            <span className="text-sm text-green-600">+15.7%</span>
          </div>
          <h3 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-2">Engagements</h3>
          <p className="text-2xl font-bold">3.4K</p>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-cyan-100 dark:bg-cyan-900/30 rounded-lg">
              <TrendingUp className="h-6 w-6 text-cyan-600" />
            </div>
            <span className="text-sm text-green-600">+10.2%</span>
          </div>
          <h3 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-2">Conversion Rate</h3>
          <p className="text-2xl font-bold">4.8%</p>
        </div>
      </div>

      {/* Additional Analytics Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Website Analytics */}
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6">
          <h2 className="text-lg font-semibold mb-6">Website Analytics</h2>
          {/* Add website analytics content */}
        </div>

        {/* Social Media Performance */}
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6">
          <h2 className="text-lg font-semibold mb-6">Social Media Performance</h2>
          {/* Add social media analytics content */}
        </div>
      </div>
    </div>
  );
}