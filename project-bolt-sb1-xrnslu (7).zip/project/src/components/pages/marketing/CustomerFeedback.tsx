import React, { useState } from 'react';
import {
  MessageSquare,
  Search,
  Filter,
  Download,
  Star,
  ThumbsUp,
  User,
  Calendar,
  RefreshCw,
  BarChart2
} from 'lucide-react';

interface Feedback {
  id: string;
  customerName: string;
  organization: string;
  rating: number;
  comment: string;
  date: string;
  product: string;
  sentiment: 'positive' | 'neutral' | 'negative';
  status: 'new' | 'reviewed' | 'responded';
}

const MOCK_FEEDBACK: Feedback[] = [
  {
    id: 'F001',
    customerName: 'John Smith',
    organization: 'City General Hospital',
    rating: 5,
    comment: 'Excellent wound care products. Has significantly improved our patient outcomes.',
    date: '2024-03-10',
    product: 'UltraHeal Pro',
    sentiment: 'positive',
    status: 'reviewed'
  },
  {
    id: 'F002',
    customerName: 'Sarah Wilson',
    organization: 'MedCare Clinic',
    rating: 4,
    comment: 'Good product but could improve packaging.',
    date: '2024-03-12',
    product: 'WoundSeal Advanced',
    sentiment: 'neutral',
    status: 'new'
  }
];

const statusColors = {
  new: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
  reviewed: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
  responded: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300'
};

const sentimentColors = {
  positive: 'text-green-500',
  neutral: 'text-yellow-500',
  negative: 'text-red-500'
};

export default function CustomerFeedback() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedSentiment, setSelectedSentiment] = useState('all');

  const filteredFeedback = MOCK_FEEDBACK.filter(feedback => {
    const matchesSearch = 
      feedback.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      feedback.comment.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = selectedStatus === 'all' || feedback.status === selectedStatus;
    const matchesSentiment = selectedSentiment === 'all' || feedback.sentiment === selectedSentiment;
    return matchesSearch && matchesStatus && matchesSentiment;
  });

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="bg-gradient-to-br from-teal-600 to-teal-800 dark:from-gray-800 dark:to-gray-900 rounded-2xl p-8 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2">Customer Feedback</h1>
              <p className="text-teal-100 dark:text-gray-300">
                Reviews and testimonials from our customers
              </p>
            </div>
            <div className="p-4 bg-white/10 rounded-xl">
              <MessageSquare className="h-8 w-8" />
            </div>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm mb-6">
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex flex-wrap gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <input
                  type="text"
                  placeholder="Search feedback..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700"
                />
              </div>
            </div>
            <div className="flex gap-4">
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700"
              >
                <option value="all">All Status</option>
                <option value="new">New</option>
                <option value="reviewed">Reviewed</option>
                <option value="responded">Responded</option>
              </select>
              <select
                value={selectedSentiment}
                onChange={(e) => setSelectedSentiment(e.target.value)}
                className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700"
              >
                <option value="all">All Sentiment</option>
                <option value="positive">Positive</option>
                <option value="neutral">Neutral</option>
                <option value="negative">Negative</option>
              </select>
            </div>
          </div>
        </div>

        <div className="p-4 flex justify-between items-center">
          <div className="flex gap-4">
            <button className="flex items-center gap-2 px-4 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700">
              Export Report
            </button>
          </div>
          <div className="flex gap-2">
            <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
              <Filter className="h-5 w-5" />
            </button>
            <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
              <Download className="h-5 w-5" />
            </button>
            <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
              <RefreshCw className="h-5 w-5" />
            </button>
            <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
              <BarChart2 className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Feedback List */}
      <div className="space-y-4">
        {filteredFeedback.map((feedback) => (
          <div
            key={feedback.id}
            className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow"
          >
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex items-center gap-2">
                    <User className="h-5 w-5 text-gray-400" />
                    <h3 className="text-lg font-semibold">{feedback.customerName}</h3>
                  </div>
                  <span className="text-sm text-gray-500">
                    {feedback.organization}
                  </span>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    statusColors[feedback.status]
                  }`}>
                    {feedback.status.charAt(0).toUpperCase() + feedback.status.slice(1)}
                  </span>
                </div>
                <div className="flex items-center gap-2 mb-4">
                  <div className="flex">
                    {[...Array(5)].map((_, index) => (
                      <Star
                        key={index}
                        className={`h-5 w-5 ${
                          index < feedback.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-sm text-gray-500">
                    for {feedback.product}
                  </span>
                </div>
                <p className="text-gray-600 dark:text-gray-300 mb-4">
                  {feedback.comment}
                </p>
                <div className="flex items-center gap-4 text-sm text-gray-500">
                  <div className="flex items-center gap-1">
                    <Calendar className="h-4 w-4" />
                    {new Date(feedback.date).toLocaleDateString()}
                  </div>
                  <div className="flex items-center gap-1">
                    <ThumbsUp className={`h-4 w-4 ${sentimentColors[feedback.sentiment]}`} />
                    {feedback.sentiment.charAt(0).toUpperCase() + feedback.sentiment.slice(1)}
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}