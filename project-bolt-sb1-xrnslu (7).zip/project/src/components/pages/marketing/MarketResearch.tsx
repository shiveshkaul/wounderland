import React from 'react';
import {
  Target,
  Search,
  Filter,
  Download,
  BarChart2,
  TrendingUp,
  Users,
  PieChart,
  RefreshCw
} from 'lucide-react';

export default function MarketResearch() {
  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="bg-gradient-to-br from-purple-600 to-purple-800 dark:from-gray-800 dark:to-gray-900 rounded-2xl p-8 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2">Market Research</h1>
              <p className="text-purple-100 dark:text-gray-300">
                Customer insights and market trends
              </p>
            </div>
            <div className="p-4 bg-white/10 rounded-xl">
              <Target className="h-8 w-8" />
            </div>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm mb-6">
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex flex-wrap gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <input
                  type="text"
                  placeholder="Search market insights..."
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
                <Filter className="h-5 w-5" />
              </button>
              <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
                <Download className="h-5 w-5" />
              </button>
              <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
                <RefreshCw className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Market Research Content */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Market Trends */}
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold">Market Trends</h2>
            <TrendingUp className="h-5 w-5 text-gray-400" />
          </div>
          {/* Add market trends content */}
        </div>

        {/* Customer Demographics */}
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold">Customer Demographics</h2>
            <Users className="h-5 w-5 text-gray-400" />
          </div>
          {/* Add demographics content */}
        </div>

        {/* Competitive Analysis */}
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold">Competitive Analysis</h2>
            <BarChart2 className="h-5 w-5 text-gray-400" />
          </div>
          {/* Add competitive analysis content */}
        </div>

        {/* Market Share */}
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold">Market Share</h2>
            <PieChart className="h-5 w-5 text-gray-400" />
          </div>
          {/* Add market share content */}
        </div>
      </div>
    </div>
  );
}