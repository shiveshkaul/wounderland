import React from 'react';
import { ArrowLeft, AlertTriangle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function SystemUpdates() {
  const navigate = useNavigate();

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <button
          onClick={() => navigate(-1)}
          className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-2xl font-bold">System Updates Required</h1>
      </div>
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6">
        <div className="flex items-center gap-3 mb-4">
          <AlertTriangle className="h-6 w-6 text-amber-500" />
          <h2 className="text-xl font-semibold">Patient Monitoring System Update</h2>
        </div>
        <p className="text-gray-600 dark:text-gray-300">
          Critical system updates are available for the patient monitoring system. Please review and apply these updates to ensure optimal performance and security.
        </p>
      </div>
    </div>
  );
}