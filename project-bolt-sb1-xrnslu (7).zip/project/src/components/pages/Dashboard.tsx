import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../../store/useStore';
import { QuickAccess } from '../dashboard/QuickAccess';
import { RecentActivity } from '../dashboard/RecentActivity';
import { Features } from '../dashboard/Features';

export default function Dashboard() {
  const navigate = useNavigate();
  const { user } = useStore();

  return (
    <div className="p-6">
      <div className="max-w-7xl mx-auto">
        {/* Welcome Section */}
        <div className="mb-8">
          <div className="bg-gradient-to-br from-blue-600 to-blue-800 dark:from-gray-800 dark:to-gray-900 rounded-2xl p-8 text-white">
            <div className="max-w-3xl">
              <h1 className="text-3xl font-bold mb-2">Welcome Back, {user.name}</h1>
              <p className="text-blue-100 dark:text-gray-300 text-lg">
                Here's what's happening in your workspace
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content Area */}
          <div className="lg:col-span-2 space-y-8">
            <Features />
            <QuickAccess />
          </div>

          {/* Sidebar */}
          <div>
            <RecentActivity />
          </div>
        </div>
      </div>
    </div>
  );
}