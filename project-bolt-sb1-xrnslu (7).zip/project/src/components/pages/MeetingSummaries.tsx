import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Video,
  Search,
  Filter,
  Download,
  Plus,
  Users,
  Clock,
  Calendar,
  FileText,
  Link as LinkIcon,
  Star,
  MoreVertical,
  RefreshCw,
  AlertCircle,
  LayoutGrid
} from 'lucide-react';
import { useMeetings } from '../../hooks/useMeetings';
import { useMicrosoftAuth } from '../../hooks/useMicrosoftAuth';
import type { Meeting } from '../../services/meetings/MeetingsService';

const statusColors = {
  Completed: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
  Scheduled: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
  Cancelled: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300'
};

export default function MeetingSummaries() {
  const navigate = useNavigate();
  const { login, isAuthenticated } = useMicrosoftAuth();
  const { fetchMeetings, loading, error } = useMeetings();
  const [meetings, setMeetings] = useState<Meeting[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');

  useEffect(() => {
    if (isAuthenticated) {
      loadMeetings();
    }
  }, [isAuthenticated]);

  const loadMeetings = async () => {
    const startDate = new Date();
    startDate.setMonth(startDate.getMonth() - 1);
    const endDate = new Date();
    endDate.setMonth(endDate.getMonth() + 1);

    const data = await fetchMeetings(startDate, endDate);
    setMeetings(data);
  };

  const filteredMeetings = meetings.filter(meeting => {
    const matchesSearch = 
      meeting.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = selectedType === 'all' || meeting.type === selectedType;
    const matchesStatus = selectedStatus === 'all' || meeting.status === selectedStatus;
    return matchesSearch && matchesType && matchesStatus;
  });

  if (!isAuthenticated) {
    return (
      <div className="p-6 max-w-7xl mx-auto">
        <div className="bg-white dark:bg-gray-800 rounded-lg p-8">
          <div className="text-center mb-6">
            <h2 className="text-2xl font-bold mb-4">Microsoft Authentication Required</h2>
            <p className="text-gray-600 dark:text-gray-400">
              Please sign in with your Microsoft account to access meeting summaries.
            </p>
          </div>
          <button
            onClick={() => login()}
            className="mx-auto flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <LayoutGrid className="h-5 w-5" />
            Sign in with Microsoft
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="bg-gradient-to-br from-blue-600 to-blue-800 dark:from-gray-800 dark:to-gray-900 rounded-2xl p-8 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2">Meeting Summaries</h1>
              <p className="text-blue-100 dark:text-gray-300">
                Access and manage meeting notes and recordings
              </p>
            </div>
            <div className="p-4 bg-white/10 rounded-xl">
              <Video className="h-8 w-8" />
            </div>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm mb-6">
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex flex-wrap gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <input
                  type="text"
                  placeholder="Search meetings..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700"
                />
              </div>
            </div>
            <div className="flex gap-4">
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700"
              >
                <option value="all">All Types</option>
                <option value="Online">Online</option>
                <option value="In-Person">In-Person</option>
              </select>
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700"
              >
                <option value="all">All Status</option>
                <option value="Scheduled">Scheduled</option>
                <option value="Completed">Completed</option>
                <option value="Cancelled">Cancelled</option>
              </select>
            </div>
          </div>
        </div>

        <div className="p-4 flex justify-between items-center">
          <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            <Plus className="h-5 w-5" />
            New Meeting
          </button>
          <div className="flex gap-2">
            <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
              <Filter className="h-5 w-5" />
            </button>
            <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
              <Download className="h-5 w-5" />
            </button>
            <button 
              onClick={loadMeetings}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
            >
              <RefreshCw className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Meetings List */}
      {loading ? (
        <div className="flex justify-center items-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      ) : error ? (
        <div className="bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 p-4 rounded-lg flex items-center gap-2">
          <AlertCircle className="h-5 w-5" />
          {error}
        </div>
      ) : (
        <div className="space-y-4">
          {filteredMeetings.map((meeting) => (
            <div
              key={meeting.id}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-semibold">{meeting.title}</h3>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      statusColors[meeting.status]
                    }`}>
                      {meeting.status}
                    </span>
                  </div>
                  {meeting.summary && (
                    <p className="text-gray-600 dark:text-gray-300 mb-4">
                      {meeting.summary}
                    </p>
                  )}
                </div>
                <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
                  <MoreVertical className="h-5 w-5" />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                  <Calendar className="h-4 w-4" />
                  {new Date(meeting.date).toLocaleDateString()}
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                  <Clock className="h-4 w-4" />
                  {meeting.duration}
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                  <Users className="h-4 w-4" />
                  {meeting.participants.length} Participants
                </div>
              </div>

              {meeting.recording && (
                <div className="mt-4 flex items-center gap-2">
                  <a
                    href={meeting.recording}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 text-blue-600 hover:text-blue-700"
                  >
                    <Video className="h-4 w-4" />
                    View Recording
                  </a>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}