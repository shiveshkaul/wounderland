import React from 'react';
import { Award, Book, Star, Trophy } from 'lucide-react';

const Profile: React.FC = () => {
  return (
    <div className="p-6">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6 mb-6">
          <div className="flex items-center gap-6">
            <div className="w-24 h-24 bg-blue-600 rounded-full flex items-center justify-center">
              <span className="text-2xl font-bold text-white">PS</span>
            </div>
            <div>
              <h1 className="text-2xl font-bold">Peter Schuck</h1>
              <p className="text-gray-600 dark:text-gray-300">Vice President Global Sales and Marketing Woundcare</p>
              <p className="text-gray-500 dark:text-gray-400">Internal Department</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Trophy className="w-5 h-5 text-blue-600" />
              Achievements
            </h2>
            <div className="space-y-4">
              {[
                'Master Wound Care Specialist',
                'Research Excellence Award',
                'Teaching Excellence',
                'Innovation Leader'
              ].map((achievement, index) => (
                <div key={index} className="flex items-center gap-3">
                  <Award className="w-5 h-5 text-amber-400" />
                  <span>{achievement}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Star className="w-5 h-5 text-blue-600" />
              Expertise
            </h2>
            <div className="space-y-4">
              {[
                'Global Sales Strategy',
                'Marketing Leadership',
                'Business Development',
                'Market Analysis'
              ].map((expertise, index) => (
                <div key={index} className="flex items-center gap-3">
                  <Book className="w-5 h-5 text-green-500" />
                  <span>{expertise}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;