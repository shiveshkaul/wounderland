import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ChevronLeft,
  Heart,
  Activity,
  Thermometer,
  Droplet,
  Clock,
  AlertCircle,
  BarChart2,
  Download,
  Filter,
  RefreshCw
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';

const mockVitalData = [
  { time: '08:00', heartRate: 72, bloodPressure: '120/80', temperature: 98.6, oxygenLevel: 98 },
  { time: '10:00', heartRate: 75, bloodPressure: '122/82', temperature: 98.7, oxygenLevel: 97 },
  { time: '12:00', heartRate: 70, bloodPressure: '118/78', temperature: 98.5, oxygenLevel: 98 },
  { time: '14:00', heartRate: 73, bloodPressure: '121/81', temperature: 98.8, oxygenLevel: 99 },
  { time: '16:00', heartRate: 71, bloodPressure: '119/79', temperature: 98.6, oxygenLevel: 98 }
];

const alerts = [
  {
    id: 1,
    type: 'warning',
    message: 'Heart rate elevated above normal range',
    time: '10:15 AM'
  },
  {
    id: 2,
    type: 'info',
    message: 'Blood pressure reading scheduled',
    time: '11:00 AM'
  },
  {
    id: 3,
    type: 'critical',
    message: 'Oxygen levels require attention',
    time: '09:45 AM'
  }
];

export default function VitalTracking() {
  const navigate = useNavigate();

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex items-center gap-4 mb-8">
        <button
          onClick={() => navigate('/')}
          className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        <h1 className="text-2xl font-bold">Real-time Vital Tracking</h1>
      </div>

      {/* Controls */}
      <div className="flex justify-between items-center mb-6">
        <div className="flex gap-4">
          <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            <Activity className="h-5 w-5" />
            Start Monitoring
          </button>
          <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700">
            <RefreshCw className="h-5 w-5" />
            Refresh Data
          </button>
        </div>
        <div className="flex gap-2">
          <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
            <Filter className="h-5 w-5" />
          </button>
          <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
            <Download className="h-5 w-5" />
          </button>
          <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
            <BarChart2 className="h-5 w-5" />
          </button>
        </div>
      </div>

      {/* Vital Signs Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-red-100 dark:bg-red-900/30 rounded-lg">
              <Heart className="h-6 w-6 text-red-600" />
            </div>
            <div>
              <h3 className="text-sm font-medium text-gray-600 dark:text-gray-400">Heart Rate</h3>
              <p className="text-2xl font-bold">72 BPM</p>
            </div>
          </div>
          <div className="h-20">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={mockVitalData}>
                <Line
                  type="monotone"
                  dataKey="heartRate"
                  stroke="#DC2626"
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
              <Activity className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <h3 className="text-sm font-medium text-gray-600 dark:text-gray-400">Blood Pressure</h3>
              <p className="text-2xl font-bold">120/80</p>
            </div>
          </div>
          <div className="h-20">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={mockVitalData}>
                <Line
                  type="monotone"
                  dataKey="heartRate"
                  stroke="#2563EB"
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-yellow-100 dark:bg-yellow-900/30 rounded-lg">
              <Thermometer className="h-6 w-6 text-yellow-600" />
            </div>
            <div>
              <h3 className="text-sm font-medium text-gray-600 dark:text-gray-400">Temperature</h3>
              <p className="text-2xl font-bold">98.6°F</p>
            </div>
          </div>
          <div className="h-20">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={mockVitalData}>
                <Line
                  type="monotone"
                  dataKey="temperature"
                  stroke="#D97706"
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-green-100 dark:bg-green-900/30 rounded-lg">
              <Droplet className="h-6 w-6 text-green-600" />
            </div>
            <div>
              <h3 className="text-sm font-medium text-gray-600 dark:text-gray-400">Oxygen Level</h3>
              <p className="text-2xl font-bold">98%</p>
            </div>
          </div>
          <div className="h-20">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={mockVitalData}>
                <Line
                  type="monotone"
                  dataKey="oxygenLevel"
                  stroke="#059669"
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Detailed Chart */}
      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm mb-8">
        <h2 className="text-lg font-semibold mb-6">Vital Signs Trend</h2>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={mockVitalData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="time" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line
                type="monotone"
                dataKey="heartRate"
                stroke="#DC2626"
                name="Heart Rate"
              />
              <Line
                type="monotone"
                dataKey="oxygenLevel"
                stroke="#059669"
                name="Oxygen Level"
              />
              <Line
                type="monotone"
                dataKey="temperature"
                stroke="#D97706"
                name="Temperature"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Alerts Section */}
      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
        <h2 className="text-lg font-semibold mb-6">Recent Alerts</h2>
        <div className="space-y-4">
          {alerts.map((alert) => (
            <div
              key={alert.id}
              className={`p-4 rounded-lg flex items-start gap-3 ${
                alert.type === 'critical'
                  ? 'bg-red-50 dark:bg-red-900/20'
                  : alert.type === 'warning'
                  ? 'bg-yellow-50 dark:bg-yellow-900/20'
                  : 'bg-blue-50 dark:bg-blue-900/20'
              }`}
            >
              <AlertCircle className={`h-5 w-5 ${
                alert.type === 'critical'
                  ? 'text-red-600'
                  : alert.type === 'warning'
                  ? 'text-yellow-600'
                  : 'text-blue-600'
              }`} />
              <div className="flex-1">
                <p className="font-medium">{alert.message}</p>
                <div className="flex items-center gap-2 mt-1 text-sm text-gray-600 dark:text-gray-400">
                  <Clock className="h-4 w-4" />
                  {alert.time}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}