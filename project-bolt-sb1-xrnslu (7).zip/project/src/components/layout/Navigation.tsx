import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { 
  Home,
  Bell,
  ClipboardList,
  FileText,
  BarChart2,
  Calendar,
  Award,
  User,
  Settings,
  MessageSquare
} from 'lucide-react';

const navItems = [
  { icon: Home, label: 'Dashboard', path: '/' },
  { icon: Calendar, label: 'Calendar', path: '/calendar' },
  { icon: ClipboardList, label: 'Tasks', path: '/tasks' },
  { icon: Bell, label: 'Announcements', path: '/announcements' },
  { icon: BarChart2, label: 'Analytics', path: '/analytics' },
  { icon: FileText, label: 'Resources', path: '/resources' },
  { icon: Award, label: 'Awards', path: '/awards' },
  { icon: MessageSquare, label: 'Messages', path: '/messages' },
  { icon: User, label: 'Profile', path: '/profile' },
  { icon: Settings, label: 'Settings', path: '/settings' }
];

export default function Navigation() {
  const location = useLocation();
  const navigate = useNavigate();

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 z-50">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between h-16 px-4 overflow-x-auto scrollbar-hide mobile-nav-scroll">
          {navItems.map((item) => (
            <button
              key={item.label}
              onClick={() => navigate(item.path)}
              className={`flex flex-col items-center gap-1 px-4 py-2 min-w-[80px] rounded-lg transition-all duration-200 ${
                location.pathname === item.path
                  ? 'text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/20'
                  : 'text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-gray-50 dark:hover:bg-gray-700'
              }`}
            >
              <item.icon className="h-5 w-5" />
              <span className="text-xs font-medium whitespace-nowrap">{item.label}</span>
            </button>
          ))}
        </div>
      </div>
    </nav>
  );
}