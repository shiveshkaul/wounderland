import React from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Calendar, Award, BarChart2, FileText, Users, Settings, ClipboardList, MessageSquare } from 'lucide-react';

interface SideMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

const menuItems = [
  {
    label: 'Calendar',
    icon: Calendar,
    path: '/calendar',
    submenu: [
      { label: 'View Calendar', path: '/calendar' },
      { label: 'Schedule Meeting', path: '/calendar/new' },
      { label: 'Upcoming Events', path: '/calendar/events' }
    ]
  },
  {
    label: 'Tasks',
    icon: ClipboardList,
    path: '/tasks',
    submenu: [
      { label: 'All Tasks', path: '/tasks' },
      { label: 'My Tasks', path: '/tasks/my-tasks' },
      { label: 'Team Tasks', path: '/tasks/team' }
    ]
  },
  {
    label: 'Communication',
    icon: MessageSquare,
    path: '/announcements',
    submenu: [
      { label: 'Announcements', path: '/announcements' },
      { label: 'Messages', path: '/messages' },
      { label: 'Updates', path: '/updates' }
    ]
  },
  {
    label: 'Awards',
    icon: Award,
    path: '/awards',
    submenu: [
      { label: 'View Awards', path: '/awards' },
      { label: 'Leaderboard', path: '/awards/leaderboard' },
      { label: 'My Achievements', path: '/awards/achievements' }
    ]
  },
  {
    label: 'Analytics',
    icon: BarChart2,
    path: '/analytics',
    submenu: [
      { label: 'Dashboard', path: '/analytics' },
      { label: 'Reports', path: '/analytics/reports' },
      { label: 'Performance', path: '/analytics/performance' }
    ]
  },
  {
    label: 'Resources',
    icon: FileText,
    path: '/resources',
    submenu: [
      { label: 'Documents', path: '/resources/documents' },
      { label: 'Training', path: '/resources/training' },
      { label: 'Guidelines', path: '/resources/guidelines' }
    ]
  },
  {
    label: 'Sales',
    icon: Users,
    path: '/sales',
    submenu: [
      { label: 'Overview', path: '/sales' },
      { label: 'Leads', path: '/sales/leads' },
      { label: 'Opportunities', path: '/sales/opportunities' }
    ]
  }
];

export default function SideMenu({ isOpen, onClose }: SideMenuProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.5 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black z-40"
          />
          
          <motion.div
            initial={{ x: '-100%' }}
            animate={{ x: 0 }}
            exit={{ x: '-100%' }}
            transition={{ type: 'tween', duration: 0.3 }}
            className="fixed inset-y-0 left-0 w-80 bg-white dark:bg-surface-800 shadow-xl z-50 overflow-y-auto"
          >
            <div className="p-4 border-b border-surface-200 dark:border-surface-700">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold">Menu</h2>
                <button
                  onClick={onClose}
                  className="p-2 rounded-lg hover:bg-surface-100 dark:hover:bg-surface-700"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <nav className="p-4">
              {menuItems.map((item) => (
                <div key={item.label} className="mb-4">
                  <div className="flex items-center gap-2 px-3 py-2 text-surface-500 text-sm font-medium">
                    <item.icon className="w-5 h-5" />
                    {item.label}
                  </div>
                  <div className="mt-1 ml-4 space-y-1">
                    {item.submenu.map((subitem) => (
                      <Link
                        key={subitem.path}
                        to={subitem.path}
                        onClick={onClose}
                        className="block px-4 py-2 text-sm rounded-lg hover:bg-surface-100 dark:hover:bg-surface-700"
                      >
                        {subitem.label}
                      </Link>
                    ))}
                  </div>
                </div>
              ))}
            </nav>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}