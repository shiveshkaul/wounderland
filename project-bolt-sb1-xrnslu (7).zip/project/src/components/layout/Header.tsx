import React from 'react';
import { Link } from 'react-router-dom';
import { Bell, Search, Settings, Moon } from 'lucide-react';
import { useStore } from '../../store/useStore';

export default function Header() {
  const { darkMode, toggleDarkMode } = useStore();

  return (
    <header className="bg-blue-600 border-b border-blue-700">
      <div className="h-8 bg-blue-700 text-white/70">
        <div className="max-w-7xl mx-auto px-4 h-full flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <span>System Status: Operational</span>
            <span>•</span>
            <span>Last Updated: {new Date().toLocaleTimeString()}</span>
          </div>
          <div className="flex items-center gap-4">
            <Link to="/support" className="hover:text-white transition-colors">Support</Link>
            <Link to="/docs" className="hover:text-white transition-colors">Documentation</Link>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 h-16">
        <div className="flex items-center justify-between h-full">
          <div className="flex items-center gap-12">
            <Link to="/" className="flex items-center gap-3">
              <span className="text-2xl font-bold text-white">Wounderland</span>
              <span className="text-sm text-white/70">Internal Department</span>
            </Link>

            <nav className="flex items-center gap-8">
              <Link to="/dashboard" className="text-white/90 hover:text-white transition-colors">Dashboard</Link>
              <Link to="/patients" className="text-white/90 hover:text-white transition-colors">Patients</Link>
              <Link to="/calendar" className="text-white/90 hover:text-white transition-colors">Calendar</Link>
              <Link to="/reports" className="text-white/90 hover:text-white transition-colors">Reports</Link>
            </nav>
          </div>

          <div className="flex items-center gap-4">
            <button className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition-colors">
              <Search className="h-5 w-5" />
            </button>
            <button className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition-colors">
              <Bell className="h-5 w-5" />
            </button>
            <button 
              onClick={toggleDarkMode}
              className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
            >
              <Moon className="h-5 w-5" />
            </button>
            <button className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition-colors">
              <Settings className="h-5 w-5" />
            </button>

            <div className="h-8 w-px bg-white/10" />

            <button className="flex items-center gap-3">
              <div className="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center text-white">
                <span className="text-sm font-medium">PS</span>
              </div>
              <div className="text-left">
                <span className="block text-sm font-medium text-white">Peter Schuck</span>
                <span className="block text-xs text-white/70">Administrator</span>
              </div>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}