import React from 'react';
import { Link } from 'react-router-dom';
import { Bell, Search, Settings, Moon } from 'lucide-react';
import { useStore } from '../../store/useStore';
import { useMicrosoftAuth } from '../../hooks/useMicrosoftAuth';

export default function TopNavigation() {
  const { darkMode, toggleDarkMode } = useStore();
  const { login, isAuthenticated, logout } = useMicrosoftAuth();

  const handleAuth = async () => {
    try {
      if (isAuthenticated) {
        await logout();
      } else {
        await login();
      }
    } catch (error) {
      console.error('Auth error:', error);
    }
  };

  return (
    <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
      <div className="max-w-7xl mx-auto px-4 h-16">
        <div className="flex items-center justify-between h-full">
          <div className="flex items-center gap-12">
            <Link to="/" className="flex items-center gap-3">
              <span className="text-2xl font-bold">Wounderland</span>
            </Link>
          </div>

          <div className="flex items-center gap-4">
            <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
              <Search className="h-5 w-5" />
            </button>
            <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
              <Bell className="h-5 w-5" />
            </button>
            <button 
              onClick={toggleDarkMode}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
            >
              <Moon className="h-5 w-5" />
            </button>
            <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
              <Settings className="h-5 w-5" />
            </button>

            <button
              onClick={handleAuth}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              {isAuthenticated ? 'Sign Out' : 'Sign in with Microsoft'}
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}