import React, { useEffect, useState } from 'react';
import { X, Bell, ExternalLink } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useStore } from '../../store/useStore';
import { fetchVivaAnnouncements } from '../../services/vivaEngage';
import type { Announcement } from '../../types';

export function FloatingAnnouncements() {
  const [isOpen, setIsOpen] = useState(true);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadAnnouncements = async () => {
    setLoading(true);
    try {
      const vivaData = await fetchVivaAnnouncements();
      setAnnouncements(vivaData);
      setError(null);
    } catch (err) {
      setError('Failed to load announcements');
      console.error('Error fetching Viva Engage announcements:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAnnouncements();
    // Refresh announcements every 5 minutes
    const interval = setInterval(loadAnnouncements, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  if (!isOpen) {
    return (
      <motion.button
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="fixed bottom-24 right-6 p-4 bg-brand-600 text-white rounded-full shadow-lg hover:bg-brand-700 transition-colors"
        onClick={() => setIsOpen(true)}
      >
        <Bell className="h-6 w-6" />
      </motion.button>
    );
  }

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 50, scale: 0.9 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 50, scale: 0.9 }}
        className="fixed bottom-24 right-6 w-96 bg-white dark:bg-gray-800 rounded-xl shadow-xl border border-gray-200 dark:border-gray-700 overflow-hidden"
      >
        {/* Header */}
        <div className="p-4 bg-brand-600 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="h-5 w-5" />
            <h3 className="font-semibold">Live Updates</h3>
          </div>
          <button
            onClick={() => setIsOpen(false)}
            className="p-1 hover:bg-white/10 rounded-lg transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content */}
        <div className="h-[400px] overflow-y-auto">
          {loading && announcements.length === 0 ? (
            <div className="flex items-center justify-center h-full">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-600"></div>
            </div>
          ) : error ? (
            <div className="p-4 text-center text-red-600 dark:text-red-400">
              {error}
              <button
                onClick={loadAnnouncements}
                className="block mx-auto mt-2 text-sm text-brand-600 hover:underline"
              >
                Try again
              </button>
            </div>
          ) : announcements.length === 0 ? (
            <div className="p-4 text-center text-gray-500 dark:text-gray-400">
              No announcements available
            </div>
          ) : (
            <div className="divide-y divide-gray-200 dark:divide-gray-700">
              {announcements.map((announcement) => (
                <div
                  key={announcement.id}
                  className="p-4 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors"
                >
                  <div className="flex justify-between items-start gap-2">
                    <div>
                      <h4 className="font-medium text-gray-900 dark:text-white">
                        {announcement.title}
                      </h4>
                      <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">
                        {announcement.description}
                      </p>
                      <div className="flex items-center gap-4 mt-2 text-sm text-gray-500 dark:text-gray-400">
                        <span>{announcement.author}</span>
                        <span>•</span>
                        <span>{new Date(announcement.date).toLocaleDateString()}</span>
                      </div>
                      {announcement.vivaLink && (
                        <a
                          href={announcement.vivaLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 mt-2 text-sm text-brand-600 hover:underline"
                        >
                          View in Viva Engage
                          <ExternalLink className="h-4 w-4" />
                        </a>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-gray-50 dark:bg-gray-800/50 border-t border-gray-200 dark:border-gray-700 flex justify-between items-center">
          <span className="text-xs text-gray-500 dark:text-gray-400">
            Last updated: {new Date().toLocaleTimeString()}
          </span>
          <button
            onClick={loadAnnouncements}
            className="text-sm text-brand-600 hover:underline"
          >
            Refresh
          </button>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}