import React, { useEffect, useState } from 'react';
import { useMicrosoftAuth } from '../../hooks/useMicrosoftAuth';
import { useSAPAuth } from '../../hooks/useSAPAuth';
import { AlertCircle, Database, LayoutGrid } from 'lucide-react';

interface AuthGatewayProps {
  children: React.ReactNode;
}

export function AuthGateway({ children }: AuthGatewayProps) {
  const { login: msLogin, isAuthenticated: isMsAuthenticated } = useMicrosoftAuth();
  const { login: sapLogin, isAuthenticated: isSapAuthenticated } = useSAPAuth();
  const [authError, setAuthError] = useState<string | null>(null);

  const handleMicrosoftLogin = async () => {
    try {
      setAuthError(null);
      await msLogin();
    } catch (error) {
      console.error('Microsoft login failed:', error);
      setAuthError('Microsoft authentication failed. Please try again.');
    }
  };

  const handleSAPLogin = async () => {
    try {
      setAuthError(null);
      await sapLogin();
    } catch (error) {
      console.error('SAP login failed:', error);
      setAuthError('SAP authentication failed. Please try again.');
    }
  };

  if (!isMsAuthenticated || !isSapAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center p-4">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 max-w-md w-full">
          <h2 className="text-2xl font-bold mb-6 text-center">Enterprise Authentication</h2>
          
          {authError && (
            <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 rounded-lg flex items-center gap-2">
              <AlertCircle className="h-5 w-5 flex-shrink-0" />
              <p>{authError}</p>
            </div>
          )}

          <div className="space-y-4">
            {!isMsAuthenticated && (
              <button
                onClick={handleMicrosoftLogin}
                className="w-full flex items-center justify-center gap-3 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <LayoutGrid className="h-5 w-5" />
                Sign in with Microsoft
              </button>
            )}

            {!isSapAuthenticated && (
              <button
                onClick={handleSAPLogin}
                className="w-full flex items-center justify-center gap-3 px-6 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
              >
                <Database className="h-5 w-5" />
                Sign in with SAP
              </button>
            )}
          </div>

          <p className="mt-4 text-sm text-gray-500 dark:text-gray-400 text-center">
            Authentication required to access enterprise features
          </p>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}