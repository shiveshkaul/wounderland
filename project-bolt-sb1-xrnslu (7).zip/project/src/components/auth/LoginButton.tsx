import React from 'react';
import { LogIn } from 'lucide-react';
import { useMicrosoftAuth } from '../../hooks/useMicrosoftAuth';

export function LoginButton() {
  const { login, isLoggingIn, error } = useMicrosoftAuth();

  const handleLogin = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    await login();
  };

  return (
    <div className="relative">
      <button
        onClick={handleLogin}
        disabled={isLoggingIn}
        className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
      >
        {isLoggingIn ? (
          <>
            <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent" />
            <span>Signing in...</span>
          </>
        ) : (
          <>
            <LogIn className="h-5 w-5" />
            <span>Sign in with Microsoft</span>
          </>
        )}
      </button>

      {error && (
        <div className="absolute top-full left-0 mt-2 w-80 p-4 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 text-sm rounded-lg shadow-lg z-50">
          <div className="flex items-center gap-2">
            <div>
              <p className="font-medium mb-1">Unable to sign in</p>
              <p>{error.message || 'An unexpected error occurred. Please try again.'}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}