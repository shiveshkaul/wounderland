import React from 'react';
import { Bell, Calendar, CheckCircle, MessageSquare } from 'lucide-react';

export const RecentActivity: React.FC = () => {
  const activities = [
    {
      id: 1,
      title: 'New Product Launch',
      description: 'Introducing our latest wound care solution',
      icon: Bell,
      time: '2h ago',
      color: 'text-blue-500',
      bgColor: 'bg-blue-100 dark:bg-blue-900/30'
    },
    {
      id: 2,
      title: 'Team Sync',
      description: 'Weekly progress review meeting summary',
      icon: MessageSquare,
      time: '3h ago',
      color: 'text-purple-500',
      bgColor: 'bg-purple-100 dark:bg-purple-900/30'
    },
    {
      id: 3,
      title: 'Achievement Unlocked',
      description: 'Team reached 95% patient satisfaction',
      icon: CheckCircle,
      time: '5h ago',
      color: 'text-emerald-500',
      bgColor: 'bg-emerald-100 dark:bg-emerald-900/30'
    },
    {
      id: 4,
      title: 'Task Completed',
      description: 'Q1 Reports finalized and submitted',
      icon: Calendar,
      time: '1d ago',
      color: 'text-amber-500',
      bgColor: 'bg-amber-100 dark:bg-amber-900/30'
    }
  ];

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Recent Activity</h2>
        <button className="text-blue-600 dark:text-blue-400 text-sm font-medium hover:text-blue-700 transition-colors">
          View All
        </button>
      </div>

      <div className="space-y-6">
        {activities.map(({ id, title, description, icon: Icon, time, color, bgColor }) => (
          <div key={id} className="flex items-start group">
            <div className={`${bgColor} p-3 rounded-xl mr-4 transition-transform duration-200 group-hover:scale-110`}>
              <Icon className={`w-5 h-5 ${color}`} />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-gray-900 dark:text-white truncate">{title}</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1 line-clamp-2">{description}</p>
              <span className="text-xs text-gray-500 dark:text-gray-500 mt-2 block">{time}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};