import React from 'react';
import { Calendar, Clock } from 'lucide-react';

export const UpcomingTasks: React.FC = () => {
  const tasks = [
    {
      id: 1,
      title: 'Patient Review Meeting',
      time: '10:00 AM',
      date: 'Today',
      priority: 'high'
    },
    {
      id: 2,
      title: 'Treatment Plan Update',
      time: '2:30 PM',
      date: 'Today',
      priority: 'medium'
    },
    {
      id: 3,
      title: 'Team Training Session',
      time: '11:00 AM',
      date: 'Tomorrow',
      priority: 'low'
    }
  ];

  const priorityColors = {
    high: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
    medium: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300',
    low: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300'
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
      <h2 className="text-lg font-semibold mb-6">Upcoming Tasks</h2>

      <div className="space-y-4">
        {tasks.map(({ id, title, time, date, priority }) => (
          <div key={id} className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
            <div className="flex justify-between items-start mb-2">
              <h3 className="font-medium">{title}</h3>
              <span className={`text-xs px-2 py-1 rounded-full ${priorityColors[priority]}`}>
                {priority}
              </span>
            </div>
            <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
              <div className="flex items-center mr-4">
                <Clock className="w-4 h-4 mr-1" />
                {time}
              </div>
              <div className="flex items-center">
                <Calendar className="w-4 h-4 mr-1" />
                {date}
              </div>
            </div>
          </div>
        ))}
      </div>

      <button className="w-full mt-6 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors">
        View All Tasks
      </button>
    </div>
  );
};