import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Package, FileText, BarChart2, Bell, CheckSquare, MessageSquare, Plus, Loader } from 'lucide-react';
import { useSharePointDirectories } from '../../hooks/useSharePointDirectories';
import { useExternalLinks } from '../../hooks/useExternalLinks';
import { ExternalLinkViewer } from '../ExternalLinkViewer';
import { AddExternalLinkModal } from '../AddExternalLinkModal';

const features = [
  {
    title: 'Product Updates',
    description: 'Latest wound care solutions',
    icon: Package,
    path: '/products',
    directoryKey: 'productUpdates',
    color: 'text-blue-600',
    bgColor: 'bg-blue-100 dark:bg-blue-900/30'
  },
  {
    title: 'Resources',
    description: 'Clinical guidelines & docs',
    icon: FileText,
    path: '/resources',
    directoryKey: 'resources',
    color: 'text-emerald-600',
    bgColor: 'bg-emerald-100 dark:bg-emerald-900/30'
  },
  {
    title: 'Sales Performance',
    description: 'Track revenue & metrics',
    icon: BarChart2,
    path: '/sales',
    directoryKey: 'sales',
    color: 'text-purple-600',
    bgColor: 'bg-purple-100 dark:bg-purple-900/30'
  }
];

const quickActions = [
  {
    title: 'Meeting Summaries',
    description: 'View meeting notes & recordings',
    icon: MessageSquare,
    path: '/meetings',
    directoryKey: 'meetings',
    color: 'text-orange-600',
    bgColor: 'bg-orange-100 dark:bg-orange-900/30'
  },
  {
    title: 'Announcements',
    description: 'Company updates & news',
    icon: Bell,
    path: '/announcements',
    directoryKey: 'announcements',
    color: 'text-pink-600',
    bgColor: 'bg-pink-100 dark:bg-pink-900/30'
  },
  {
    title: 'Task Tracking',
    description: 'Manage team tasks',
    icon: CheckSquare,
    path: '/tasks',
    directoryKey: 'tasks',
    color: 'text-cyan-600',
    bgColor: 'bg-cyan-100 dark:bg-cyan-900/30'
  }
];

export function Features() {
  const navigate = useNavigate();
  const { directories, loading: loadingDirectories } = useSharePointDirectories();
  const { links, addLink, loading: loadingLinks } = useExternalLinks();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [showAddLinkModal, setShowAddLinkModal] = useState(false);

  const handleAddLink = async (linkData: any) => {
    try {
      await addLink(linkData);
      setShowAddLinkModal(false);
    } catch (error) {
      console.error('Error adding link:', error);
    }
  };

  const renderFeatureContent = (feature: any) => {
    const isLoading = loadingDirectories || loadingLinks;
    const categoryLinks = links[feature.directoryKey] || [];
    
    return (
      <div>
        <p className="text-sm text-gray-600 dark:text-gray-400">{feature.description}</p>
        {isLoading ? (
          <div className="mt-3 flex items-center text-sm text-blue-600">
            <Loader className="h-4 w-4 mr-2 animate-spin" />
            Loading...
          </div>
        ) : (
          <>
            {categoryLinks.length > 0 && (
              <div className="mt-4 space-y-2">
                {categoryLinks.map(link => (
                  <div key={link.id} className="relative">
                    <ExternalLinkViewer
                      link={link}
                      className="bg-gray-50 dark:bg-gray-700/50 rounded-lg"
                    />
                  </div>
                ))}
              </div>
            )}

            <div 
              onClick={(e) => {
                e.stopPropagation();
                setSelectedCategory(feature.directoryKey);
                setShowAddLinkModal(true);
              }}
              className="mt-3 flex items-center gap-1 text-sm text-blue-600 hover:text-blue-700 cursor-pointer"
            >
              <Plus className="h-4 w-4" />
              Add External Link
            </div>
          </>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-8">
      {/* Main Features */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {features.map((feature) => (
          <motion.div
            key={feature.title}
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => navigate(feature.path)}
            className="w-full relative overflow-hidden bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600 transition-all duration-300 hover:shadow-lg cursor-pointer"
          >
            <div className="p-6">
              <div className="flex items-center gap-3 mb-3">
                <div className={`p-2 rounded-lg ${feature.bgColor}`}>
                  <feature.icon className={`h-5 w-5 ${feature.color}`} />
                </div>
                <h3 className="font-semibold text-gray-900 dark:text-white">{feature.title}</h3>
              </div>
              {renderFeatureContent(feature)}
            </div>
          </motion.div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {quickActions.map((action) => (
          <motion.div
            key={action.title}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => navigate(action.path)}
            className="w-full flex items-center gap-4 p-4 bg-white dark:bg-gray-800 rounded-xl hover:shadow-md transition-all cursor-pointer"
          >
            <div className={`p-2 rounded-lg ${action.bgColor}`}>
              <action.icon className={`h-5 w-5 ${action.color}`} />
            </div>
            <div className="text-left">
              <h3 className="font-medium text-gray-900 dark:text-white">{action.title}</h3>
              {renderFeatureContent(action)}
            </div>
          </motion.div>
        ))}
      </div>

      {/* Add External Link Modal */}
      {showAddLinkModal && selectedCategory && (
        <AddExternalLinkModal
          onAdd={handleAddLink}
          category={selectedCategory}
          onClose={() => setShowAddLinkModal(false)}
        />
      )}
    </div>
  );
}