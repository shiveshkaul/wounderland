import React from 'react';
import { Link } from 'react-router-dom';
import { Activity, Calendar, Brain, Workflow } from 'lucide-react';

const quickAccessItems = [
  {
    title: 'Announcements',
    description: 'Global & local updates hub',
    icon: Activity,
    path: '/announcements',
    color: 'text-blue-600',
    bgColor: 'bg-blue-100/50 dark:bg-blue-900/30',
    borderColor: 'border-blue-200 dark:border-blue-800'
  },
  {
    title: 'Meeting Summaries',
    description: 'Comprehensive meeting hub',
    icon: Calendar,
    path: '/meetings',
    color: 'text-purple-600',
    bgColor: 'bg-purple-100/50 dark:bg-purple-900/30',
    borderColor: 'border-purple-200 dark:border-purple-800'
  },
  {
    title: 'Sales Performance',
    description: 'Advanced analytics dashboard',
    icon: Brain,
    path: '/sales',
    color: 'text-emerald-600',
    bgColor: 'bg-emerald-100/50 dark:bg-emerald-900/30',
    borderColor: 'border-emerald-200 dark:border-emerald-800'
  },
  {
    title: 'Task Tracking',
    description: 'Intelligent task management',
    icon: Workflow,
    path: '/tasks',
    color: 'text-amber-600',
    bgColor: 'bg-amber-100/50 dark:bg-amber-900/30',
    borderColor: 'border-amber-200 dark:border-amber-800'
  }
];

export function QuickAccess() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {quickAccessItems.map((item) => (
        <Link
          key={item.title}
          to={item.path}
          className="group relative overflow-hidden bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600 transition-all duration-300 hover:shadow-lg"
        >
          <div className="p-6">
            <div className="flex items-center gap-4">
              <div className={`p-3 rounded-xl ${item.bgColor} ${item.color} transition-all duration-300 group-hover:scale-110`}>
                <item.icon className="h-6 w-6" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white mb-1">
                  {item.title}
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {item.description}
                </p>
              </div>
            </div>
          </div>
          <div className={`absolute inset-0 ${item.bgColor} opacity-0 group-hover:opacity-5 transition-opacity duration-300`} />
        </Link>
      ))}
    </div>
  );
}