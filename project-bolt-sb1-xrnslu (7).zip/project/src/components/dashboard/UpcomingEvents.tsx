import React from 'react';
import { Calendar, Clock, MapPin, Users } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function UpcomingEvents() {
  const navigate = useNavigate();

  const events = [
    {
      id: 1,
      title: 'Product Launch Meeting',
      type: 'Virtual',
      time: '10:00 AM',
      date: 'Today',
      attendees: 12
    },
    {
      id: 2,
      title: 'Sales Team Sync',
      type: 'In-Person',
      time: '2:30 PM',
      date: 'Today',
      attendees: 8
    },
    {
      id: 3,
      title: 'Client Presentation',
      type: 'Virtual',
      time: '11:00 AM',
      date: 'Tomorrow',
      attendees: 5
    }
  ];

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold">Upcoming Events</h2>
        <button
          onClick={() => navigate('/calendar')}
          className="text-sm text-blue-600 hover:text-blue-700"
        >
          View Calendar
        </button>
      </div>

      <div className="space-y-4">
        {events.map((event) => (
          <div
            key={event.id}
            className="p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors cursor-pointer"
            onClick={() => navigate(`/calendar/event/${event.id}`)}
          >
            <h3 className="font-medium mb-2">{event.title}</h3>
            <div className="flex flex-wrap gap-4 text-sm text-gray-600 dark:text-gray-400">
              <div className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                {event.time}
              </div>
              <div className="flex items-center gap-1">
                <Calendar className="h-4 w-4" />
                {event.date}
              </div>
              <div className="flex items-center gap-1">
                <MapPin className="h-4 w-4" />
                {event.type}
              </div>
              <div className="flex items-center gap-1">
                <Users className="h-4 w-4" />
                {event.attendees} attendees
              </div>
            </div>
          </div>
        ))}
      </div>

      <button
        onClick={() => navigate('/calendar/new')}
        className="w-full mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
      >
        Schedule Event
      </button>
    </div>
  );
}