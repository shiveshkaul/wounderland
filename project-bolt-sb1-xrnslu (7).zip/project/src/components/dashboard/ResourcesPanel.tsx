import React from 'react';
import { FileText, Video, Book, Link as LinkIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function ResourcesPanel() {
  const navigate = useNavigate();

  const resources = [
    {
      title: 'Product Documentation',
      description: 'Complete guides and API references',
      icon: FileText,
      link: '/resources/docs',
      type: 'Technical'
    },
    {
      title: 'Training Videos',
      description: 'Step-by-step video tutorials',
      icon: Video,
      link: '/resources/videos',
      type: 'Training'
    },
    {
      title: 'Best Practices Guide',
      description: 'Implementation guidelines and tips',
      icon: Book,
      link: '/resources/guides',
      type: 'Guide'
    },
    {
      title: 'API Documentation',
      description: 'Integration endpoints and examples',
      icon: LinkIcon,
      link: '/resources/api',
      type: 'Technical'
    }
  ];

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold">Resources</h2>
        <button
          onClick={() => navigate('/resources')}
          className="text-sm text-blue-600 hover:text-blue-700"
        >
          View All
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {resources.map((resource) => (
          <button
            key={resource.title}
            onClick={() => navigate(resource.link)}
            className="flex items-start gap-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors text-left"
          >
            <div className="p-2 bg-white dark:bg-gray-800 rounded-lg shadow-sm">
              <resource.icon className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <h3 className="font-medium mb-1">{resource.title}</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                {resource.description}
              </p>
              <span className="inline-block mt-2 text-xs px-2 py-1 bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-200 rounded-full">
                {resource.type}
              </span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}