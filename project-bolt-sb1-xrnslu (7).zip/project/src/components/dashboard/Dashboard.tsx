import React from 'react';
import { motion } from 'framer-motion';
import { Features } from './Features';
import { RecentActivity } from './RecentActivity';

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 }
};

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-secondary-50 dark:bg-secondary-900">
      <div className="bg-gradient-premium dark:bg-gradient-premium-dark">
        <div className="max-w-7xl mx-auto px-4 py-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20"
          >
            <h1 className="text-3xl font-bold text-white">Welcome Back, Peter Schuck</h1>
            <p className="mt-2 text-primary-100">Your wound care marketing & communications hub</p>
          </motion.div>
        </div>
      </div>

      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="max-w-7xl mx-auto px-4 -mt-8"
      >
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <motion.div variants={item} className="lg:col-span-2">
            <Features />
          </motion.div>
          <motion.div variants={item}>
            <RecentActivity />
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}