import React from 'react';
import { Award, BookOpen, Beaker, Stethoscope } from 'lucide-react';
import { useStore } from '../../store/useStore';
import { useNavigate } from 'react-router-dom';

export const PointsCard: React.FC = () => {
  const { user } = useStore();
  const navigate = useNavigate();

  const categories = [
    { name: 'Clinical', icon: Stethoscope, value: user.points.clinical, color: 'text-emerald-500', barColor: 'bg-emerald-500' },
    { name: 'Research', icon: Beaker, value: user.points.research, color: 'text-blue-500', barColor: 'bg-blue-500' },
    { name: 'Education', icon: BookOpen, value: user.points.education, color: 'text-purple-500', barColor: 'bg-purple-500' },
    { name: 'Innovation', icon: Award, value: user.points.innovation, color: 'text-amber-500', barColor: 'bg-amber-500' }
  ];

  const handleViewAwards = () => {
    navigate('/wcc-awards');
  };

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-xl font-bold mb-1">WCC Points</h2>
          <p className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-blue-800 bg-clip-text text-transparent">
            850
          </p>
        </div>
        <div className="p-3 bg-blue-100 dark:bg-blue-900/30 rounded-xl">
          <Award className="h-8 w-8 text-blue-600" />
        </div>
      </div>
      
      <div className="space-y-6">
        {categories.map(({ name, icon: Icon, value, color, barColor }) => (
          <div key={name} className="group">
            <div className="flex items-center mb-2">
              <Icon className={`w-5 h-5 ${color} mr-3`} />
              <div className="flex-1">
                <div className="flex justify-between items-center">
                  <span className="font-medium">{name}</span>
                  <span className={`font-semibold ${color}`}>{value}%</span>
                </div>
              </div>
            </div>
            <div className="relative h-2 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden">
              <div
                className={`absolute left-0 top-0 h-full ${barColor} rounded-full transition-all duration-500 ease-out group-hover:opacity-80`}
                style={{ width: `${value}%` }}
              />
            </div>
          </div>
        ))}
      </div>

      <button
        onClick={handleViewAwards}
        className="w-full mt-8 px-6 py-3 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white rounded-xl font-semibold shadow-sm hover:shadow-md transition-all duration-200"
      >
        View All Awards
      </button>
    </div>
  );
};