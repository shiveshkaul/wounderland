import React from 'react';
import { useAuth } from '../../services/auth/AuthContext';
import {
  LogIn,
  Microsoft,
  Database,
  Cloud,
  CheckCircle,
  AlertCircle
} from 'lucide-react';

export function IntegrationsPanel() {
  const { login, isAuthenticated } = useAuth();

  const handleLogin = async (service: 'microsoft' | 'salesforce' | 'sap') => {
    try {
      await login(service);
    } catch (error) {
      console.error(`Error logging into ${service}:`, error);
    }
  };

  const integrations = [
    {
      name: 'Microsoft 365',
      description: 'Connect to Teams, SharePoint & more',
      icon: Microsoft,
      status: isAuthenticated ? 'connected' : 'disconnected',
      action: () => handleLogin('microsoft'),
      features: ['Teams', 'SharePoint', 'OneDrive', 'Outlook']
    },
    {
      name: 'Salesforce',
      description: 'CRM & Sales Analytics',
      icon: Cloud,
      status: isAuthenticated ? 'connected' : 'disconnected', 
      action: () => handleLogin('salesforce'),
      features: ['Leads', 'Opportunities', 'Analytics', 'Reports']
    },
    {
      name: 'SAP',
      description: 'Enterprise Resource Planning',
      icon: Database,
      status: isAuthenticated ? 'connected' : 'disconnected',
      action: () => handleLogin('sap'),
      features: ['Sales Data', 'Inventory', 'Analytics', 'Reports']
    }
  ];

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
      <h2 className="text-xl font-bold mb-6">Enterprise Integrations</h2>
      <div className="space-y-6">
        {integrations.map((integration) => (
          <div 
            key={integration.name}
            className="flex items-start gap-6 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          >
            <div className="p-3 bg-white dark:bg-gray-800 rounded-xl shadow-sm">
              <integration.icon className="h-6 w-6 text-blue-600" />
            </div>
            
            <div className="flex-1">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold">{integration.name}</h3>
                <div className="flex items-center gap-2">
                  {integration.status === 'connected' ? (
                    <span className="flex items-center gap-1 text-sm text-green-600">
                      <CheckCircle className="h-4 w-4" />
                      Connected
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-sm text-gray-500">
                      <AlertCircle className="h-4 w-4" />
                      Not Connected
                    </span>
                  )}
                </div>
              </div>
              
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                {integration.description}
              </p>

              <div className="flex flex-wrap gap-2 mb-4">
                {integration.features.map((feature) => (
                  <span 
                    key={feature}
                    className="px-2 py-1 text-xs bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-200 rounded-full"
                  >
                    {feature}
                  </span>
                ))}
              </div>

              <button
                onClick={integration.action}
                className={`flex items-center gap-2 px-4 py-2 text-sm rounded-lg transition-colors ${
                  integration.status === 'connected'
                    ? 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                    : 'bg-blue-600 text-white hover:bg-blue-700'
                }`}
              >
                <LogIn className="h-4 w-4" />
                {integration.status === 'connected' ? 'Manage Connection' : 'Connect'}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}