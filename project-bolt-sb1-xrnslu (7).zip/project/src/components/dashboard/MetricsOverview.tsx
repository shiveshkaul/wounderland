import React from 'react';
import {
  TrendingUp,
  Users,
  Calendar,
  Clock,
  ArrowUp,
  ArrowDown,
  Activity
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts';

const mockData = [
  { month: 'Jan', sales: 4500, engagement: 1200, tasks: 280 },
  { month: 'Feb', sales: 5200, engagement: 1500, tasks: 320 },
  { month: 'Mar', sales: 4800, engagement: 1350, tasks: 300 },
  { month: 'Apr', sales: 6100, engagement: 1800, tasks: 410 },
  { month: 'May', sales: 5500, engagement: 1650, tasks: 380 },
  { month: 'Jun', sales: 6700, engagement: 2000, tasks: 450 }
];

interface MetricCardProps {
  title: string;
  value: string;
  change: string;
  icon: React.ElementType;
  trend: 'up' | 'down';
}

const MetricCard: React.FC<MetricCardProps> = ({ title, value, change, icon: Icon, trend }) => (
  <div className="bg-white dark:bg-gray-800 rounded-xl p-6">
    <div className="flex items-center justify-between mb-4">
      <div className="p-3 bg-blue-100 dark:bg-blue-900/30 rounded-xl">
        <Icon className="h-6 w-6 text-blue-600" />
      </div>
      <span className={`flex items-center text-sm ${
        trend === 'up' ? 'text-green-600' : 'text-red-600'
      }`}>
        {trend === 'up' ? <ArrowUp className="h-4 w-4 mr-1" /> : <ArrowDown className="h-4 w-4 mr-1" />}
        {change}
      </span>
    </div>
    <h3 className="text-gray-600 dark:text-gray-400 text-sm font-medium mb-2">{title}</h3>
    <p className="text-2xl font-bold">{value}</p>
  </div>
);

export function MetricsOverview() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Total Sales"
          value="$328,500"
          change="+15.3%"
          icon={TrendingUp}
          trend="up"
        />
        <MetricCard
          title="Active Users"
          value="1,245"
          change="+8.1%"
          icon={Users}
          trend="up"
        />
        <MetricCard
          title="Completed Tasks"
          value="384"
          change="+12.5%"
          icon={Clock}
          trend="up"
        />
        <MetricCard
          title="Engagement Rate"
          value="64%"
          change="-2.3%"
          icon={Activity}
          trend="down"
        />
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-xl p-6">
        <h3 className="text-lg font-semibold mb-6">Performance Overview</h3>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={mockData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Line 
                type="monotone" 
                dataKey="sales" 
                stroke="#3B82F6" 
                name="Sales"
                strokeWidth={2}
              />
              <Line 
                type="monotone" 
                dataKey="engagement" 
                stroke="#10B981" 
                name="Engagement"
                strokeWidth={2}
              />
              <Line 
                type="monotone" 
                dataKey="tasks" 
                stroke="#6366F1" 
                name="Tasks"
                strokeWidth={2}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}