import React from 'react';
import { ExternalLink } from '../hooks/useExternalLinks';
import { useExternalLinkFetcher } from '../hooks/useExternalLinkFetcher';
import { Loader, AlertCircle, ExternalLink as LinkIcon } from 'lucide-react';

interface Props {
  link: ExternalLink;
  className?: string;
}

export function ExternalLinkViewer({ link, className = '' }: Props) {
  const { content, loading, error, refetch } = useExternalLinkFetcher(link);

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader className="h-6 w-6 animate-spin text-blue-600" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center p-8 text-red-600">
        <AlertCircle className="h-8 w-8 mb-2" />
        <p className="text-sm text-center mb-4">{error}</p>
        <button
          onClick={() => refetch()}
          className="px-4 py-2 bg-red-100 hover:bg-red-200 rounded-lg text-sm"
        >
          Try Again
        </button>
      </div>
    );
  }

  if (!content) {
    return (
      <div className="flex items-center justify-center p-8 text-gray-500">
        No content available
      </div>
    );
  }

  return (
    <div className={`relative ${className}`}>
      <div className="rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
        {content.type === 'embed' ? (
          <iframe
            src={content.embedUrl}
            title={link.title}
            className="w-full min-h-[400px] border-0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
        ) : content.type === 'image' ? (
          <img src={content.data} alt={link.title} className="max-w-full h-auto" />
        ) : content.type === 'json' ? (
          <pre className="p-4 overflow-auto">
            {JSON.stringify(content.data, null, 2)}
          </pre>
        ) : (
          <div className="p-4 whitespace-pre-wrap">{content.data}</div>
        )}
      </div>
      
      <a
        href={link.url}
        target="_blank"
        rel="noopener noreferrer"
        className="absolute top-2 right-2 p-2 bg-white/90 dark:bg-gray-800/90 rounded-lg shadow hover:bg-white dark:hover:bg-gray-800 transition-colors"
        onClick={(e) => e.stopPropagation()}
      >
        <LinkIcon className="h-4 w-4" />
      </a>
    </div>
  );
}