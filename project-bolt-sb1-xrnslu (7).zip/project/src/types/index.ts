export interface Announcement {
  id: string;
  title: string;
  category: 'Technical Update' | 'Clinical Update' | 'Events' | 'General';
  description: string;
  date: string;
  author: string;
  source?: 'internal' | 'viva';
  vivaLink?: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  read: boolean;
  date: string;
  timestamp: string;
  link?: string;
}